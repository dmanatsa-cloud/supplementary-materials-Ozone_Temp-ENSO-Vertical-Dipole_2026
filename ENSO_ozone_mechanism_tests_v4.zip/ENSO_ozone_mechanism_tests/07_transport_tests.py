"""Step 7. Does the ozone-temperature association survive transport controls?

Adds the MLS N2O tracer (step 2) and the ERA5 residual upwelling w* (step 4)
to the paper's principal model, using the same regression, inference and
four-region adjustment as Table 3.

  python 07_transport_tests.py
  python 07_transport_tests.py --exclude-winters 2025   # drop a thin N2O winter

Outputs in RESULTS_DIR: transport_tests.csv, transport_tests.md, transport_tests.png
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import settings as S  # noqa: E402
from common import COMMON, PRINCIPAL, REGIONS, TRANSPORT, ensure_dirs, family, load_package_winter, log  # noqa: E402

N2O = "n2o_anomaly_ppbv"


def load(exclude):
    d = load_package_winter()
    res = Path(S.RESULTS_DIR)
    have = {"n2o": False, "wstar": False}
    f = res / "N2O_footprint_winter.csv"
    if f.exists():
        n = pd.read_csv(f)[["winter_year", "hemisphere", "p", N2O, "n_profiles_min"]]
        d = d.merge(n, on=["winter_year", "hemisphere", "p"], how="left")
        have["n2o"] = d[N2O].notna().sum() > 30
    f = res / "wstar_winter.csv"
    if f.exists():
        w = pd.read_csv(f)[["winter_year", "hemisphere", "p", "wstar_tropics", "wstar_band"]]
        d = d.merge(w, on=["winter_year", "hemisphere", "p"], how="left")
        have["wstar"] = d["wstar_tropics"].notna().sum() > 30
    if exclude:
        d = d[~d.winter_year.isin(exclude)]
    return d, have


def run(d, have, B, seed):
    rng = np.random.default_rng(seed)
    models = [("Principal", COMMON, [])]
    if have["n2o"]:
        models += [("Principal + N2O", COMMON + [N2O], [N2O]),
                   ("Transport model + N2O", COMMON + TRANSPORT + [N2O], [N2O])]
    if have["wstar"]:
        models += [("Principal + w* 20S-20N", COMMON + ["wstar_tropics"], ["wstar_tropics"]),
                   ("Principal + w* own band", COMMON + ["wstar_band"], ["wstar_band"])]
    if have["n2o"] and have["wstar"]:
        models += [("Principal + N2O + w*", COMMON + [N2O, "wstar_tropics"], [N2O, "wstar_tropics"])]
    needed = sorted({c for _, _, extra in models for c in extra})
    common_sample = d.dropna(subset=needed) if needed else d
    out = []
    for label, controls, _ in models:
        r = family(common_sample, controls, label, rng=rng, B=B)
        out.append(r)
    diag = []
    if have["n2o"]:
        diag.append(family(common_sample, COMMON, "N2O vs temperature", x=N2O, y="t", rng=rng, B=B))
        diag.append(family(common_sample, COMMON, "N2O vs ozone", x=N2O, y="ozone_anomaly_ppmv", rng=rng, B=B))
    if have["wstar"]:
        diag.append(family(common_sample, COMMON, "w* vs temperature", x="wstar_tropics", y="t", rng=rng, B=B))
        diag.append(family(common_sample, COMMON, "w* vs ozone", x="wstar_tropics", y="ozone_anomaly_ppmv", rng=rng, B=B))
    return pd.concat(out, ignore_index=True), (pd.concat(diag, ignore_index=True) if diag else pd.DataFrame()), common_sample


def verdict(base, test, tracer_t, kind, power=None):
    r0, r1, q1 = base.partial_r, test.partial_r, test.q_cons
    tracer_sig = tracer_t is not None and tracer_t.q_cons < 0.05
    if r1 >= 0.6 and q1 < 0.05:
        if kind == "n2o" and (power is None or power.q_cons >= 0.05):
            return ("Not decisive: ozone still predicts temperature with N2O in the model, but N2O does not "
                    "track ozone in this region (see tracer strength), so the test cannot rule out shared transport.")
        if kind == "n2o":
            return ("Not weakened: ozone still predicts temperature with N2O in the model, and N2O tracks ozone here. "
                    "This is consistent with an ozone-specific effect but does not exclude transport.")
        if kind == "wstar":
            return ("Not weakened: the zonal-mean upwelling index does not account for the association. "
                    "This does not show that upwelling contributes nothing, and it cannot address local transport.")
        return "Not weakened by either control; this does not exclude transport."
    if (r1 < 0.3 or q1 > 0.2) and tracer_sig:
        return ("Absorbed: the control takes over the association, as shared transport would. "
                "This does not by itself measure a transport share.")
    if r1 < 0.5 * r0:
        return ("Strongly reduced: consistent with a shared transport contribution, but this does not measure its "
                "size.")
    return "Attenuated but not removed: consistent with some shared transport; inconclusive at this sample size."


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--exclude-winters", type=int, nargs="*", default=[])
    ap.add_argument("--permutations", type=int, default=S.PERMUTATIONS)
    a = ap.parse_args()
    ensure_dirs()
    d, have = load(a.exclude_winters)
    if not (have["n2o"] or have["wstar"]):
        sys.exit("Neither N2O_footprint_winter.csv nor wstar_winter.csv found in RESULTS_DIR. Run steps 1-4 first.")
    res, diag, sample = run(d, have, a.permutations, S.RANDOM_SEED)
    out = Path(S.RESULTS_DIR)
    res.to_csv(out / "transport_tests.csv", index=False)
    if len(diag):
        diag.to_csv(out / "transport_diagnostics.csv", index=False)

    cols = ["model", "region", "n", "df", "partial_r", "slope", "q_classical", "q_HAC", "q_FL", "q_cons"]
    print("\nOzone-temperature association under each model (four-region adjusted q):")
    print(res[cols].round(4).to_string(index=False))
    if len(diag):
        print("\nTracer and upwelling diagnostics (principal covariates):")
        print(diag[["model", "region", "n", "partial_r", "q_cons"]].round(3).to_string(index=False))

    lines = ["# Transport-control tests", "",
             f"Winters used: {sample.winter_year.min()}-{sample.winter_year.max()} "
             f"({sample.winter_year.nunique()} winters"
             f"{'; excluded ' + ', '.join(map(str, a.exclude_winters)) if a.exclude_winters else ''}). "
             f"Permutations: {a.permutations:,}.", ""]
    lines += ["| Model | Region | n | df | Partial r | q_cons |", "|---|---|---|---|---|---|"]
    for _, r in res.iterrows():
        lines.append(f"| {r.model} | {r.region} | {r.n} | {r.df} | {r.partial_r:+.3f} | {r.q_cons:.4f} |")
    if len(diag):
        lines += ["", "| Diagnostic | Region | Partial r | q_cons |", "|---|---|---|---|"]
        for _, r in diag.iterrows():
            lines.append(f"| {r.model} | {r.region} | {r.partial_r:+.3f} | {r.q_cons:.4f} |")
    lines += ["", "## Reading for the two principal regions", ""]
    base = res[res.model == "Principal"].set_index("region")
    for h, p in PRINCIPAL:
        reg = f"{h} {p}"
        lines.append(f"**{h.title()} {p} hPa** (principal model r = {base.loc[reg].partial_r:.2f}, same winters)")
        lines.append("")
        for label, tracer, kind in [("Principal + N2O", "N2O vs temperature", "n2o"),
                                    ("Principal + w* 20S-20N", "w* vs temperature", "wstar"),
                                    ("Principal + N2O + w*", None, "both")]:
            t = res[(res.model == label) & (res.region == reg)]
            if t.empty:
                continue
            tt = diag[(diag.model == tracer) & (diag.region == reg)].iloc[0] if (tracer and len(diag) and
                                                                                  (diag.model == tracer).any()) else None
            pw = diag[(diag.model == "N2O vs ozone") & (diag.region == reg)] if len(diag) else []
            pw = pw.iloc[0] if len(pw) else None
            lines.append(f"- {label}: r = {t.iloc[0].partial_r:.2f}, q_cons = {t.iloc[0].q_cons:.4f}. "
                         f"{verdict(base.loc[reg], t.iloc[0], tt, kind, pw)}")
        if len(diag) and (diag.model == "N2O vs ozone").any():
            no = diag[(diag.model == "N2O vs ozone") & (diag.region == reg)].iloc[0]
            lines.append(f"- Tracer strength: N2O vs ozone partial r = {no.partial_r:+.2f}. A strong negative value "
                         "means N2O captures the transported part of ozone. A weak value means the N2O test has "
                         "little power: near the tropical tropopause N2O has a much weaker vertical gradient than "
                         "ozone, so measurement noise can hide its transport signal.")
        lines.append("")
    lines += ["Expected signs if transport drives both: N2O vs ozone negative (upwelling raises N2O and lowers ozone) "
              "and N2O vs temperature negative (upwelling cools). w* vs temperature negative.", ""]
    (out / "transport_tests.md").write_text("\n".join(lines), encoding="utf-8")
    log(f"Wrote {out / 'transport_tests.md'}")
    try:
        figure(res, out)
    except Exception as e:
        log(f"figure skipped: {e}")


def figure(res, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    models = list(dict.fromkeys(res.model))
    fig, ax = plt.subplots(figsize=(7.5, 0.45 * len(models) * 2 + 1.2))
    colors = {"south 68.1": "#1f4e79", "north 100.0": "#b5402f", "north 68.1": "#9a9a9a", "south 100.0": "#c8c8c8"}
    offs = {"south 68.1": 0.24, "north 100.0": 0.08, "north 68.1": -0.08, "south 100.0": -0.24}
    for i, m in enumerate(models):
        y = len(models) - 1 - i
        for reg, g in res[res.model == m].groupby("region"):
            r = g.iloc[0]
            filled = r.q_cons < 0.05
            ax.scatter(r.partial_r, y + offs[reg], s=40, color=colors[reg] if filled else "white",
                       edgecolor=colors[reg], linewidth=1.4, zorder=3, label=reg if i == 0 else None)
    ax.set_yticks(range(len(models)))
    ax.set_yticklabels(models[::-1])
    ax.axvline(0, color="#bbbbbb", lw=0.8)
    ax.set_xlim(-0.6, 1.0)
    ax.set_xlabel("Ozone-temperature partial correlation (filled: q_cons < 0.05)")
    ax.legend(frameon=False, fontsize=8.5, loc="lower left")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(out / "transport_tests.png", dpi=200)


if __name__ == "__main__":
    main()
