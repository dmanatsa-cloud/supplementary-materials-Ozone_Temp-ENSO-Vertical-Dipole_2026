"""Edit this file once. Every script reads its paths and choices from here.

Use raw strings (r"...") for Windows paths. Keep DATA_DIR outside OneDrive:
OneDrive will try to sync several gigabytes of temporary downloads.

Each path can also be set with an environment variable of the same name
(the self-test uses this to run on synthetic files).
"""
import os
from pathlib import Path


def _path(name, default):
    return Path(os.environ.get(name, default)).expanduser()


# 1. The "outputs" folder inside ENSO_ozone_review_reproducibility_package.
#    It must contain Focused_ozone_evidence_2026_10_06 and
#    ENSO_ozone_review_revision_2026_10_06.
PACKAGE_OUTPUTS = _path(
    "PACKAGE_OUTPUTS",
    r"C:\Users\ict\OneDrive\Desktop\Research papers\OHC, OZONE and ENSO paper"
    r"\ENSO_ozone_review_reproducibility_package\outputs",
)

# 2. The SWOOSH 3D file you already used for the paper.
SWOOSH_FILE = _path(
    "SWOOSH_FILE",
    r"C:\Users\ict\OneDrive\Desktop\Research papers\OHC, OZONE and ENSO paper"
    r"\swoosh-v02.73-198401-202606-lonlatpress-20deg-5deg-L31.nc",
)

# 3. Working folder for downloads, reduced data and results (outside OneDrive).
DATA_DIR = _path("DATA_DIR", r"C:\ENSO_mechanism_data")
RESULTS_DIR = _path("RESULTS_DIR", str(DATA_DIR / "results"))

# ---------------------------------------------------------------------------
# Analysis choices (no need to change these)
# ---------------------------------------------------------------------------
WINTERS = list(range(2005, 2026))      # DJF winters named by Jan-Feb year
PILOT_WINTERS = [2008, 2011, 2016]      # small first run to check timing
MASK = "original_2K"                    # footprint used in the paper

# Aura MLS (NASA GES DISC). Version 006 is the current recommended release.
MLS_VERSION = "006"
MLS_SCREENING = {
    # v6.0x data quality document: use profiles with even Status,
    # Quality > threshold, Convergence < threshold and Precision > 0.
    "N2O": {"swath": "N2O", "quality": 0.8, "convergence": 2.0, "scale": 1e9, "unit": "ppbv"},
    "O3": {"swath": "O3", "quality": 1.0, "convergence": 1.03, "scale": 1e6, "unit": "ppmv"},
}
MLS_PRESSURE_RANGE = (40.0, 160.0)      # hPa kept from each profile
MLS_LON_RANGE = (200.0, 240.0)          # SWOOSH cells centred at 210 and 230 E
MLS_LAT_RANGE = (-30.0, 30.0)
MLS_MIN_PROFILES_PER_CELL_MONTH = 10

# ERA5 for the residual circulation (Copernicus Climate Data Store)
WSTAR_LEVELS_HPA = [50, 70, 100, 125, 150]
WSTAR_GRID_DEG = 1.5
WSTAR_AREA = [45, -180, -45, 180]       # north, west, south, east
WSTAR_TIMES = ["00:00", "06:00", "12:00", "18:00"]
WSTAR_TROPICS = (-20.0, 20.0)

# ERA5 for the radiation calculation (monthly means, all 37 levels)
RAD_AREA = [29.5, -160, -29.5, -130]    # matches the 0.5 degree footprint grid
RAD_GRID_DEG = 0.5
RAD_YEARS = list(range(2004, 2026))

# Radiation experiment settings (06b)
RAD_FDH_TOP_OF_FIXED_HPA = 125.0        # levels at or above this pressure are adjusted
RAD_OZONE_BOTTOM_HPA = 150.0            # ozone anomaly set to zero below this level
RAD_CO2_PPMV = 400.0
RAD_CH4_PPBV = 1850.0
RAD_N2O_PPBV = 330.0
RAD_R_LIQ_MICRON = 12.0
RAD_R_ICE_MICRON = 40.0
RAD_SOLAR_CONSTANT = 1361.0

# Statistics
PERMUTATIONS = 19999
RANDOM_SEED = 20261007
