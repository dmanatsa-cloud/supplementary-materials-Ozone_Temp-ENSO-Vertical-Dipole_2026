"""Synthetic files in the real formats, used only by 99_selftest.py.

They let you check the installation and every processing step before any
large download. The numbers are made up; do not interpret the results.
"""
import calendar
import datetime as dt
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import xarray as xr

SW_LEVELS = 1000.0 * 10 ** (-np.arange(6, 37) / 12.0)          # 316 to 1 hPa, 12 per decade
MLS_LEVELS = 1000.0 * 10 ** (-np.arange(0, 49) / 12.0)         # 1000 to 0.1 hPa
ERA5_LEVELS = [1, 2, 3, 5, 7, 10, 20, 30, 50, 70, 100, 125, 150, 175, 200, 225, 250, 300, 350, 400,
               450, 500, 550, 600, 650, 700, 750, 775, 800, 825, 850, 875, 900, 925, 950, 975, 1000]


def tropical_profile(p):
    p = np.asarray(p, float)
    z = -7.0 * np.log(p / 1000.0)
    T = np.where(z < 16.5, 300 - 6.5 * z, 193 + (z - 16.5) * 1.6)
    T = np.where(z > 30, 214.6 + (z - 30) * 2.5, T)
    q = np.maximum(0.018 * np.exp(-z / 2.4), 3.5e-6)
    o3 = np.exp(np.interp(np.log(p), np.log([1, 5, 10, 20, 30, 50, 70, 100, 150, 1000]),
                          np.log([3e-6, 8e-6, 9e-6, 7e-6, 5e-6, 1.5e-6, 0.35e-6, 0.08e-6, 0.04e-6, 0.03e-6])))
    cc = np.where((p > 120) & (p < 250), 0.15, np.where((p > 700) & (p < 950), 0.10, 0.0))
    clwc = np.where((p > 700) & (p < 950), 2e-5, 0.0)
    ciwc = np.where((p > 120) & (p < 250), 4e-6, 0.0)
    return T, q, o3, cc, clwc, ciwc


def package_monthly(pkg_outputs):
    m = pd.read_csv(Path(pkg_outputs) / "Focused_ozone_evidence_2026_10_06" /
                    "observed_ozone_T_cloud_lobe_monthly_2005_2025.csv")
    m["p"] = m.pressure_hpa.round(1)
    return m


def o3_anom_profile(levels, a68, a100):
    """Vertical shape of a synthetic ozone anomaly given the values at 68 and 100 hPa."""
    lp = np.log(levels)
    xs = np.log([30, 46.4, 56.2, 68.13, 100.0, 121.2, 146.8])
    ys = [0, 0.25 * a68, 0.5 * a68, a68, a100, 0.5 * a100, 0.0]
    o = np.argsort(xs)
    return np.interp(lp, np.array(xs)[o], np.array(ys)[o], left=0.0, right=0.0)


# ---------------------------------------------------------------------------
def make_mls(folder, pkg_outputs, winters, days=(1, 5, 9, 13, 17, 21, 25, 28), seed=1):
    """Daily MLS L2GP N2O files with the real HDF-EOS5 layout."""
    rng = np.random.default_rng(seed)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    mon = package_monthly(pkg_outputs)
    base = 320.0 * np.clip((MLS_LEVELS / 150.0) ** 0.15, 0, 1.0)  # ppbv, decreasing upward
    for w in winters:
        for (y, m) in [(w - 1, 12), (w, 1), (w, 2)]:
            sel = mon[(mon.winter_year == w) & (mon.month == m)]
            for d in days:
                date = dt.date(y, m, min(d, calendar.monthrange(y, m)[1]))
                n = 90
                lat = rng.uniform(-35, 35, n)
                lon = rng.uniform(-170, -110, n)          # MLS uses -180..180
                val = np.tile(base, (n, 1)) + rng.normal(0, 12, (n, len(MLS_LEVELS)))
                for i in range(n):
                    h = "north" if lat[i] >= 0 else "south"
                    g = sel[sel.hemisphere == h].set_index("p").ozone_anomaly_ppmv
                    if len(g) == 2:
                        val[i] += -60.0 * o3_anom_profile(MLS_LEVELS, g.get(68.1, 0), g.get(100.0, 0))
                prec = np.full_like(val, 15.0)
                prec[:, :3] = -15.0                        # a priori dominated near the surface
                status = np.where(rng.random(n) < 0.03, 1, 0).astype(np.int32)
                quality = np.where(rng.random(n) < 0.03, 0.3, 1.6).astype(np.float32)
                conv = np.full(n, 1.0, np.float32)
                secs = (dt.datetime(date.year, date.month, date.day, 12) - dt.datetime(1993, 1, 1)).total_seconds()
                time = secs + np.arange(n) * 25.0
                fn = folder / f"MLS-Aura_L2GP-N2O_v06-00-c01_{date.year}d{date.timetuple().tm_yday:03d}.he5"
                with h5py.File(fn, "w") as f:
                    for sw in ("N2O", "N2O-APriori"):
                        g = f.create_group(f"/HDFEOS/SWATHS/{sw}")
                        dfld, gfld = g.create_group("Data Fields"), g.create_group("Geolocation Fields")
                        dfld["L2gpValue"] = (val * 1e-9).astype(np.float32)
                        dfld["L2gpPrecision"] = (prec * 1e-9).astype(np.float32)
                        dfld["Status"] = status
                        dfld["Quality"] = quality
                        dfld["Convergence"] = conv
                        gfld["Latitude"] = lat.astype(np.float32)
                        gfld["Longitude"] = lon.astype(np.float32)
                        gfld["Pressure"] = MLS_LEVELS.astype(np.float32)
                        gfld["Time"] = time
    return folder


# ---------------------------------------------------------------------------
def make_wstar_months(folder, pkg_outputs, winters, steps=4, seed=2):
    """Small ERA5-like 6-hourly files (YYYYMM.nc) with eddies and ENSO-dependent ascent."""
    rng = np.random.default_rng(seed)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    nino = pd.read_csv(Path(pkg_outputs) / "Focused_ozone_evidence_2026_10_06" /
                       "observed_ozone_T_cloud_lobe_winter_2005_2025.csv").drop_duplicates("winter_year") \
        .set_index("winter_year").nino34
    lat = np.arange(45, -45.1, -3.0)
    lon = np.arange(-180, 180, 3.0)
    lev = np.array([50, 70, 100, 125, 150], float)
    T0 = tropical_profile(lev)[0]
    for w in winters:
        for (y, m) in [(w - 1, 12), (w, 1), (w, 2)]:
            times = pd.date_range(f"{y}-{m:02d}-01", periods=steps, freq="6h")
            nt = len(times)
            phi = np.deg2rad(lat)
            asc = -3e-4 * (1 + 0.25 * nino.get(w, 0)) * np.cos(phi / np.deg2rad(45) * np.pi / 2) ** 2
            omega = np.broadcast_to(asc[None, None, :, None], (nt, len(lev), len(lat), len(lon))).copy()
            omega += rng.normal(0, 2e-5, omega.shape)
            wave = np.cos(np.deg2rad(2 * lon))[None, None, None, :]
            amp = (np.abs(lat) / 45.0)[None, None, :, None]
            v = 3.0 * amp * wave + rng.normal(0, 0.5, (nt, len(lev), len(lat), len(lon)))
            T = T0[None, :, None, None] + 1.0 * amp * wave * np.sign(lat)[None, None, :, None] \
                + rng.normal(0, 0.2, (nt, len(lev), len(lat), len(lon)))
            ds = xr.Dataset({"t": (("valid_time", "pressure_level", "latitude", "longitude"), T.astype("f4")),
                             "v": (("valid_time", "pressure_level", "latitude", "longitude"), v.astype("f4")),
                             "w": (("valid_time", "pressure_level", "latitude", "longitude"), omega.astype("f4"))},
                            coords=dict(valid_time=times, pressure_level=lev, latitude=lat, longitude=lon))
            ds.to_netcdf(folder / f"{y}{m:02d}.nc")
    return folder


# ---------------------------------------------------------------------------
def make_era5_radiation(folder, years):
    """Monthly-mean files laid out like the CDS netCDF output (horizontally uniform)."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    lat = np.arange(29.5, -29.51, -0.5)
    lon = np.arange(-160, -129.99, 0.5)
    times = [pd.Timestamp(y, m, 1) for y in years for m in (1, 2, 12)]
    T, q, o3, cc, clwc, ciwc = tropical_profile(ERA5_LEVELS)
    fields = {"t": T, "q": q, "o3": o3 * 47.9982 / 28.9644, "cc": cc, "clwc": clwc, "ciwc": ciwc}
    names = {"t": "temperature", "q": "specific_humidity", "o3": "ozone_mass_mixing_ratio",
             "cc": "fraction_of_cloud_cover", "clwc": "specific_cloud_liquid_water_content",
             "ciwc": "specific_cloud_ice_water_content"}
    shape = (len(times), len(ERA5_LEVELS), len(lat), len(lon))
    enc = dict(zlib=True, complevel=1)
    for k, prof in fields.items():
        a = np.broadcast_to(np.asarray(prof, "f4")[None, :, None, None], shape)
        ds = xr.Dataset({k: (("valid_time", "pressure_level", "latitude", "longitude"), a)},
                        coords=dict(valid_time=times, pressure_level=np.array(ERA5_LEVELS, float), latitude=lat, longitude=lon))
        ds.to_netcdf(folder / f"pl_{names[k]}.nc", encoding={k: enc})
    s = (len(times), len(lat), len(lon))
    ds = xr.Dataset({"skt": (("valid_time", "latitude", "longitude"), np.full(s, 301.0, "f4")),
                     "sp": (("valid_time", "latitude", "longitude"), np.full(s, 101000.0, "f4")),
                     "fal": (("valid_time", "latitude", "longitude"), np.full(s, 0.06, "f4"))},
                    coords=dict(valid_time=times, latitude=lat, longitude=lon))
    ds.to_netcdf(folder / "sl_surface.nc", encoding={v: enc for v in ds.data_vars})
    return folder


# ---------------------------------------------------------------------------
def make_swoosh(path, pkg_outputs):
    """SWOOSH-like 3D file whose footprint anomalies equal the paper's monthly series."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    mon = package_monthly(pkg_outputs)
    lat = np.arange(-87.5, 90, 5.0)
    lon = np.arange(10, 360, 20.0)
    years, months = [], []
    for y in range(1984, 2027):
        for m in range(1, 13):
            if y == 2026 and m > 6:
                break
            years.append(y)
            months.append(m)
    years, months = np.array(years), np.array(months)
    base = tropical_profile(SW_LEVELS)[2] * 1e6
    o3 = np.broadcast_to(base[None, :, None, None], (len(years), len(SW_LEVELS), len(lat), len(lon))).copy()
    hemi_of_lat = np.where(lat >= 0, "north", "south")
    # anomalies for DJF 2005-2025 from the paper; Sep-Nov at half the DJF mean
    keyed = {}
    for (w, m, h), g in mon.groupby(["winter_year", "month", "hemisphere"]):
        s = g.set_index("p").ozone_anomaly_ppmv
        y = w - 1 if m == 12 else w
        keyed[(y, m, h)] = o3_anom_profile(SW_LEVELS, s.get(68.1, 0.0), s.get(100.0, 0.0))
    for h in ("north", "south"):
        for w in range(2005, 2026):
            djf = [keyed.get((w - 1, 12, h)), keyed.get((w, 1, h)), keyed.get((w, 2, h))]
            if all(x is not None for x in djf):
                for m in (9, 10, 11):
                    keyed[(w - 1, m, h)] = 0.5 * np.mean(djf, axis=0)
    # offset 1991-2004 so that the 1991-2020 climatology equals the base profile
    for h in ("north", "south"):
        for m in range(1, 13):
            ks = [k for k in keyed if k[1] == m and k[2] == h and 1991 <= k[0] <= 2020]
            free = [y for y in range(1991, 2021) if (y, m, h) not in keyed]
            if ks and free:
                total = np.sum([keyed[k] for k in ks], axis=0)
                for y in free:
                    keyed[(y, m, h)] = -total / len(free)
    for i, (y, m) in enumerate(zip(years, months)):
        for h in ("north", "south"):
            a = keyed.get((y, m, h))
            if a is not None:
                sel = (hemi_of_lat == h) & (np.abs(lat) <= 30)
                o3[i][:, sel, :] += a[:, None, None]
    # Real SWOOSH has no tropical ozone at its lowest level; keep that gap so the test covers it
    o3[:, int(np.argmax(SW_LEVELS)), np.abs(lat) <= 30, :] = np.nan
    ds = xr.Dataset({"combinedo3q": (("time", "level", "lat", "lon"), o3.astype("f4")),
                     "year": (("time",), years.astype("i4")), "month": (("time",), months.astype("i4"))},
                    coords=dict(time=np.arange(len(years)), level=SW_LEVELS, lat=lat, lon=lon))
    ds.to_netcdf(path, encoding={"combinedo3q": dict(zlib=True, complevel=1)})
    return path
