"""Read and screen Aura MLS Level 2 (L2GP, HDF-EOS5) files and keep the study region."""
import datetime as dt

import h5py
import numpy as np
import pandas as pd

import settings as S

TAI93 = dt.datetime(1993, 1, 1)


def read_swath(path, swath):
    with h5py.File(path, "r") as f:
        root = "/HDFEOS/SWATHS"
        if root not in f:
            raise ValueError(f"{path} is not an MLS L2GP file (no {root}).")
        if swath not in f[root]:
            raise KeyError(f"Swath '{swath}' not found. Swaths in file: {list(f[root].keys())}")
        d = f[f"{root}/{swath}/Data Fields"]
        g = f[f"{root}/{swath}/Geolocation Fields"]
        out = {k: d[k][()] for k in ("L2gpValue", "L2gpPrecision", "Status", "Quality", "Convergence")}
        out.update({k: g[k][()] for k in ("Latitude", "Longitude", "Pressure", "Time")})
    return out


def extract_region(path, product="N2O"):
    """Screened profiles inside the study region, long format.

    Columns: date, time_tai93, lat, lon (0-360), pressure_hpa, value (ppbv or ppmv), precision.
    """
    cfg = S.MLS_SCREENING[product]
    s = read_swath(path, cfg["swath"])
    val = np.asarray(s["L2gpValue"], float)
    prec = np.asarray(s["L2gpPrecision"], float)
    status = np.asarray(s["Status"]).astype(np.int64)
    qual = np.asarray(s["Quality"], float)
    conv = np.asarray(s["Convergence"], float)
    lat = np.asarray(s["Latitude"], float)
    lon = np.asarray(s["Longitude"], float) % 360
    pres = np.asarray(s["Pressure"], float)
    time = np.asarray(s["Time"], float)

    good_profile = ((status % 2) == 0) & (qual > cfg["quality"]) & (conv < cfg["convergence"])
    in_region = ((lat >= S.MLS_LAT_RANGE[0]) & (lat < S.MLS_LAT_RANGE[1])
                 & (lon >= S.MLS_LON_RANGE[0]) & (lon < S.MLS_LON_RANGE[1]))
    keep_p = (pres >= S.MLS_PRESSURE_RANGE[0]) & (pres <= S.MLS_PRESSURE_RANGE[1])
    rows = np.where(good_profile & in_region)[0]
    cols = np.where(keep_p)[0]
    if len(rows) == 0 or len(cols) == 0:
        return pd.DataFrame(columns=["date", "time_tai93", "lat", "lon", "pressure_hpa", "value", "precision"]), \
            dict(n_profiles=int(len(lat)), n_good=int(good_profile.sum()), n_region=0)
    v = val[np.ix_(rows, cols)]
    e = prec[np.ix_(rows, cols)]
    ok = (e > 0) & (v > -900) & np.isfinite(v)
    rr, cc = np.where(ok)
    t = time[rows][rr]
    dates = [(TAI93 + dt.timedelta(seconds=float(x))).date().isoformat() for x in t]
    df = pd.DataFrame(dict(date=dates, time_tai93=t, lat=lat[rows][rr], lon=lon[rows][rr],
                           pressure_hpa=pres[cols][cc], value=v[rr, cc] * cfg["scale"],
                           precision=e[rr, cc] * cfg["scale"]))
    info = dict(n_profiles=int(len(lat)), n_good=int(good_profile.sum()), n_region=int(len(rows)))
    return df, info
