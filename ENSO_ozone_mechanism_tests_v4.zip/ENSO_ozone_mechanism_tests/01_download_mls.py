"""Step 1. Download Aura MLS Level 2 N2O (and optionally O3) for DJF 2004/05 to 2024/25.

Each daily file is downloaded, reduced to the study region (200-240 E,
30 S-30 N, 40-160 hPa, quality-screened) and then deleted, so the disk
never holds more than one raw file. The script can be stopped and
restarted at any time: finished days are skipped.

Examples
  python 01_download_mls.py --pilot              # 3 winters, to time it
  python 01_download_mls.py                      # all 21 winters of N2O
  python 01_download_mls.py --product O3 --pilot # optional ozone check
  python 01_download_mls.py --from-local-dir D:\\mls_files   # files you already have
"""
import argparse
import calendar
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402

import settings as S  # noqa: E402
from common import djf_months, ensure_dirs, log  # noqa: E402
from mls_reader import extract_region  # noqa: E402


def out_dir(product):
    d = Path(S.DATA_DIR) / "mls" / product
    d.mkdir(parents=True, exist_ok=True)
    return d


def write_day(df, info, product, date, source, logrows):
    path = out_dir(product) / f"{date}.csv.gz"
    df.to_csv(path, index=False)
    logrows.append(dict(date=date, file=source, **info, rows=len(df)))


def append_log(product, logrows):
    if not logrows:
        return
    p = Path(S.DATA_DIR) / "mls" / f"{product}_download_log.csv"
    new = pd.DataFrame(logrows)
    if p.exists():
        new = pd.concat([pd.read_csv(p), new], ignore_index=True).drop_duplicates("date", keep="last")
    new.sort_values("date").to_csv(p, index=False)


def from_local(folder, product):
    files = sorted(Path(folder).glob(f"MLS-Aura_L2GP-{product}_*.he5"))
    if not files:
        sys.exit(f"No MLS-Aura_L2GP-{product}_*.he5 files in {folder}")
    logrows = []
    for i, f in enumerate(files, 1):
        df, info = extract_region(f, product)
        date = df.date.mode().iloc[0] if len(df) else _date_from_name(f.name)
        write_day(df, info, product, date, f.name, logrows)
        if i % 50 == 0:
            log(f"{i}/{len(files)} files reduced")
    append_log(product, logrows)
    log(f"Done: {len(files)} files reduced into {out_dir(product)}")


def _date_from_name(name):
    # MLS-Aura_L2GP-N2O_v06-00-c01_2005d001.he5
    import datetime as dt
    tag = name.split("_")[-1].split(".")[0]
    y, d = tag.split("d")
    return (dt.date(int(y), 1, 1) + dt.timedelta(days=int(d) - 1)).isoformat()


def download(product, winters, keep_raw, dry_run):
    import earthaccess
    log("Logging in to NASA Earthdata ...")
    auth = earthaccess.login(persist=True)
    if not getattr(auth, "authenticated", False):
        sys.exit("Earthdata login failed. See README step 2.")
    raw = Path(S.DATA_DIR) / "mls" / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    short = f"ML2{product}"
    for w in winters:
        (y0, _), _, (y1, _) = djf_months(w)
        end_day = calendar.monthrange(y1, 2)[1]
        temporal = (f"{y0}-12-01T00:00:00", f"{y1}-02-{end_day}T23:59:59")
        grans = earthaccess.search_data(short_name=short, version=S.MLS_VERSION, temporal=temporal)
        log(f"Winter {w}: {len(grans)} daily {short} v{S.MLS_VERSION} files found")
        if dry_run:
            continue
        logrows = []
        for g in grans:
            date = g["umm"]["TemporalExtent"]["RangeDateTime"]["BeginningDateTime"][:10]
            if (out_dir(product) / f"{date}.csv.gz").exists():
                continue
            for attempt in range(1, 4):
                try:
                    try:
                        files = earthaccess.download([g], local_path=str(raw), show_progress=False)
                    except TypeError:  # older earthaccess without show_progress
                        files = earthaccess.download([g], local_path=str(raw))
                    he5 = [Path(f) for f in files if str(f).endswith(".he5")]
                    if not he5:
                        raise RuntimeError(f"no .he5 file returned for {date}")
                    df, info = extract_region(he5[0], product)
                    write_day(df, info, product, date, he5[0].name, logrows)
                    if not keep_raw:
                        for f in files:
                            Path(f).unlink(missing_ok=True)
                    break
                except Exception as e:  # network hiccups are common on long runs
                    log(f"  {date} attempt {attempt} failed: {e}")
                    time.sleep(10 * attempt)
            else:
                log(f"  {date} skipped after 3 attempts; rerun the script later to retry")
        append_log(product, logrows)
        log(f"Winter {w} finished ({len(logrows)} new days)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--product", default="N2O", choices=["N2O", "O3"])
    ap.add_argument("--pilot", action="store_true", help="only the pilot winters in settings.py")
    ap.add_argument("--winters", type=int, nargs="*", help="e.g. --winters 2010 2016")
    ap.add_argument("--keep-raw", action="store_true", help="keep the raw .he5 files")
    ap.add_argument("--dry-run", action="store_true", help="search only; report file counts")
    ap.add_argument("--from-local-dir", help="reduce .he5 files already on disk instead of downloading")
    a = ap.parse_args()
    ensure_dirs()
    if a.from_local_dir:
        return from_local(a.from_local_dir, a.product)
    winters = a.winters or (S.PILOT_WINTERS if a.pilot else S.WINTERS)
    download(a.product, winters, a.keep_raw, a.dry_run)


if __name__ == "__main__":
    main()
