"""Shared helpers: paths, footprints, SWOOSH sampling and the regression tests."""
import datetime as dt
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

import settings as S

HERE = Path(__file__).resolve().parent
REGIONS = [("south", 68.1), ("north", 100.0), ("north", 68.1), ("south", 100.0)]
PRINCIPAL = [("south", 68.1), ("north", 100.0)]
TARGET_LEVELS = {68.1: 68.1292, 100.0: 100.0}
COMMON = ["nino34", "nino34_sq", "qbo30", "qbo50", "trend",
          "ice_water_path_g_m2_anomaly", "skin_temperature_K_anomaly",
          "LS_specific_humidity_mg_kg_anomaly"]
TRANSPORT = ["h", "v", "omega"]
SWOOSH_LEVELS = np.array([146.78, 121.15, 100.0, 82.54, 68.13, 56.23, 46.42])


def log(msg):
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def ensure_dirs():
    for p in [S.DATA_DIR, S.RESULTS_DIR]:
        Path(p).mkdir(parents=True, exist_ok=True)


def winter_of(year, month):
    return year + 1 if month == 12 else year


def djf_months(winter):
    return [(winter - 1, 12), (winter, 1), (winter, 2)]


# ---------------------------------------------------------------------------
# Package inputs
# ---------------------------------------------------------------------------
def package_file(*parts):
    p = Path(S.PACKAGE_OUTPUTS).joinpath(*parts)
    if not p.exists():
        sys.exit(f"Cannot find {p}\nCheck PACKAGE_OUTPUTS in settings.py.")
    return p


def load_package_winter():
    d = pd.read_csv(package_file("Focused_ozone_evidence_2026_10_06",
                                 "observed_ozone_T_cloud_lobe_winter_2005_2025.csv"))
    d["p"] = d.pressure_hpa.round(1)
    return d


def load_package_monthly():
    d = pd.read_csv(package_file("Focused_ozone_evidence_2026_10_06",
                                 "observed_ozone_T_cloud_lobe_monthly_2005_2025.csv"))
    d["p"] = d.pressure_hpa.round(1)
    return d


def footprint_weights(mask=None, hemisphere="south"):
    """Horizontal footprint weights on the 0.5 degree ERA5 grid (sum to 1)."""
    mask = mask or S.MASK
    z = np.load(package_file("ENSO_ozone_review_revision_2026_10_06", "alternative_footprints.npz"))
    return z["latitude"], z["longitude"], z[f"{mask}_{hemisphere}"]


def swoosh_cell_weights(mask=None, hemisphere="south"):
    """Overlap weights of the footprint on native SWOOSH cells (5 x 20 degrees).

    Reproduces the weighting used for the paper: each 0.5 degree footprint
    cell contributes in proportion to its latitude and clipped longitude
    overlap with each SWOOSH cell centred at 210 or 230 E.
    Returns a DataFrame with lat_center, lon_center and weight (sum 1).
    """
    lat, lon, w = footprint_weights(mask, hemisphere)
    dx = np.maximum(0, np.minimum(lon + .25, 230) - np.maximum(lon - .25, 200))
    rows = []
    for la in np.arange(-27.5, 30, 5.0):
        dy = np.maximum(0, np.minimum(lat + .25, la + 2.5) - np.maximum(lat - .25, la - 2.5))
        for lo in (210.0, 230.0):
            dd = np.maximum(0, np.minimum(np.minimum(lon + .25, 230), lo + 10)
                            - np.maximum(np.maximum(lon - .25, 200), lo - 10))
            with np.errstate(divide="ignore", invalid="ignore"):
                frac = np.where(dx > 0, dd / (.5 * dx), 0.0)
            rows.append(dict(lat_center=la, lon_center=lo, weight=float(np.sum(w * dy[:, None] * frac[None, :]))))
    c = pd.DataFrame(rows)
    c["weight"] /= c.weight.sum()
    return c[c.weight > 0].reset_index(drop=True)


def footprint_mean(cell_values, cell_weights, min_coverage=0.8):
    """Weighted footprint mean from a cell table (lat_center, lon_center, value)."""
    m = cell_weights.merge(cell_values, on=["lat_center", "lon_center"], how="left")
    ok = m.value.notna()
    cover = m.weight[ok].sum()
    if cover < min_coverage:
        return np.nan, cover
    return float((m.weight[ok] * m.value[ok]).sum() / cover), cover


# ---------------------------------------------------------------------------
# SWOOSH
# ---------------------------------------------------------------------------
def read_swoosh_cells(path=None, pmin=1.0, pmax=320.0):
    """Monthly SWOOSH combinedo3q (ppmv) for the cells at 210 and 230 E, |lat| <= 30."""
    from netCDF4 import Dataset
    path = Path(path or S.SWOOSH_FILE)
    if not path.exists():
        sys.exit(f"Cannot find the SWOOSH file {path}\nCheck SWOOSH_FILE in settings.py.")
    with Dataset(path) as ds:
        year = np.asarray(ds["year"][:], int)
        month = np.asarray(ds["month"][:], int)
        lat = np.asarray(ds["lat"][:], float)
        lon = np.asarray(ds["lon"][:], float) % 360
        lev = np.asarray(ds["level"][:], float)
        yi = np.where(np.abs(lat) <= 30)[0]
        xi = [int(np.argmin(np.abs(lon - x))) for x in (210, 230)]
        pi = np.where((lev >= pmin) & (lev <= pmax))[0]
        var = ds["combinedo3q"]
        dims = var.dimensions
        data = np.ma.asarray(var[:]).filled(np.nan).astype(float)
    # bring to (time, level, lat, lon) whatever the stored order
    names = {d.lower(): i for i, d in enumerate(dims)}
    tdim = next(i for n, i in names.items() if n.startswith("time"))
    ldim = next(i for n, i in names.items() if n.startswith("lev") or n.startswith("pres") or n == "plev")
    adim = next(i for n, i in names.items() if n.startswith("lat"))
    odim = next(i for n, i in names.items() if n.startswith("lon"))
    data = np.transpose(data, (tdim, ldim, adim, odim))[:, pi][:, :, yi][:, :, :, xi]
    return dict(year=year, month=month, level=lev[pi], lat=lat[yi], lon=np.array([210.0, 230.0]), o3=data)


def swoosh_footprint_anomalies(sw, cells, months_wanted, clim_years=(1991, 2020)):
    """Footprint-weighted ozone anomaly profiles (ppmv) for (year, month) keys.

    Anomalies are taken per native cell from the calendar-month mean over
    clim_years, then averaged with the footprint overlap weights.
    """
    key = sw["year"] * 100 + sw["month"]
    out = {}
    clim = {}
    for m in range(1, 13):
        sel = (sw["month"] == m) & (sw["year"] >= clim_years[0]) & (sw["year"] <= clim_years[1])
        with np.errstate(invalid="ignore"):
            clim[m] = np.nanmean(sw["o3"][sel], axis=0)
    li = {round(float(v), 4): i for i, v in enumerate(sw["lat"])}
    wmat = np.zeros((len(sw["lat"]), 2))
    for _, r in cells.iterrows():
        wmat[li[round(float(r.lat_center), 4)], 0 if r.lon_center == 210 else 1] = r.weight
    for (y, m) in months_wanted:
        idx = np.where(key == y * 100 + m)[0]
        if len(idx) == 0:
            out[(y, m)] = np.full(len(sw["level"]), np.nan)
            continue
        a = sw["o3"][idx[0]] - clim[m]
        prof = []
        for k in range(a.shape[0]):
            ok = np.isfinite(a[k])
            cover = wmat[ok].sum()
            prof.append(np.nan if cover < 0.8 else float((a[k][ok] * wmat[ok]).sum() / cover))
        out[(y, m)] = np.array(prof)
    return out


# ---------------------------------------------------------------------------
# Regression with classical, HAC and Freedman-Lane inference
# (same implementation as the 7 October recalculation)
# ---------------------------------------------------------------------------
def bh(p):
    p = np.asarray(p, float)
    m = len(p)
    o = np.argsort(p)
    q = np.empty(m)
    prev = 1.0
    for rank in range(m, 0, -1):
        i = o[rank - 1]
        prev = min(prev, p[i] * m / rank)
        q[i] = prev
    return q


def design(g, controls):
    g = g.sort_values("winter_year").copy()
    g["nino34_sq"] = g["nino34"] ** 2
    g["trend"] = g.winter_year - 2015
    Z = g[controls].to_numpy(float)
    Z = (Z - Z.mean(0)) / Z.std(0)
    return g, np.column_stack([np.ones(len(g)), Z])


def resid(y, C):
    b, *_ = np.linalg.lstsq(C, y, rcond=None)
    return y - C @ b


def _hac(X, e, XtX_inv, lag=1):
    n, k = X.shape
    u = X * e[:, None]
    Sm = u.T @ u
    for L in range(1, lag + 1):
        w = 1 - L / (lag + 1)
        G = u[L:].T @ u[:-L]
        Sm += w * (G + G.T)
    return XtX_inv @ Sm @ XtX_inv * n / (n - k)


def _freedman_lane(y, x, C, rng, B):
    rx, ry = resid(x, C), resid(y, C)
    X = np.column_stack([C, x])
    n, k = X.shape
    df = n - k
    Q, _ = np.linalg.qr(X)
    ss = rx @ rx

    def tstat(E):
        beta = E @ rx / ss
        sse = ((E - (E @ Q) @ Q.T) ** 2).sum(1)
        return beta / np.sqrt(sse / df / ss)

    t0 = abs(tstat(ry[None, :])[0])
    idx = np.argsort(rng.random((B, n)), axis=1)
    t = np.abs(tstat(ry[idx]))
    return (1 + np.count_nonzero(t >= t0 - 1e-12)) / (B + 1)


def fit(g, controls, x="ozone_anomaly_ppmv", y="t", rng=None, B=None):
    g = g.dropna(subset=[x, y] + [c for c in controls if c not in ("nino34_sq", "trend")])
    g, C = design(g, controls)
    xv = g[x].to_numpy(float)
    yv = g[y].to_numpy(float)
    X = np.column_stack([C, xv])
    XtX_inv = np.linalg.inv(X.T @ X)
    b = XtX_inv @ X.T @ yv
    e = yv - X @ b
    n, k = X.shape
    df = n - k
    s2 = e @ e / df
    se = np.sqrt(s2 * XtX_inv[-1, -1])
    se_h = np.sqrt(_hac(X, e, XtX_inv)[-1, -1])
    tc = stats.t.ppf(0.975, df)
    r = float(np.corrcoef(resid(xv, C), resid(yv, C))[0, 1])
    out = dict(n=n, df=df, partial_r=r, slope=b[-1], ci_lo=b[-1] - tc * se, ci_hi=b[-1] + tc * se,
               p_classical=2 * stats.t.sf(abs(b[-1] / se), df),
               p_HAC=2 * stats.t.sf(abs(b[-1] / se_h), df))
    if rng is not None:
        out["p_FL"] = _freedman_lane(yv, xv, C, rng, B or S.PERMUTATIONS)
    return out


def family(data, controls, label, x="ozone_anomaly_ppmv", y="t", rng=None, B=None, regions=REGIONS):
    """Fit all regions, then Benjamini-Hochberg adjust each method across regions."""
    rows = []
    for h, p in regions:
        g = data[(data.hemisphere == h) & (data.p == p)]
        r = fit(g, controls, x, y, rng, B)
        r.update(model=label, region=f"{h} {p}")
        rows.append(r)
    for m in ("classical", "HAC", "FL"):
        if f"p_{m}" in rows[0]:
            for row, q in zip(rows, bh([row[f"p_{m}"] for row in rows])):
                row[f"q_{m}"] = q
    for row in rows:
        row["q_cons"] = max(row[k] for k in ("q_classical", "q_HAC", "q_FL") if k in row)
    return pd.DataFrame(rows)
