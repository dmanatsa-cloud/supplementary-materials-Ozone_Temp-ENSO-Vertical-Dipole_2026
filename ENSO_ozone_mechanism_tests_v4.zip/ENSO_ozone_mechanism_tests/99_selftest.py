"""Self-test: run every step on small synthetic files in the real formats.

Run this after installing the environment and before any big download.
It needs only the reproducibility package (for the footprints and the
paper's series). It writes to DATA_DIR/selftest and does not touch any
real data. Synthetic numbers are meaningless; only PASS/FAIL matters.

  python 99_selftest.py
"""
import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import settings as S  # noqa: E402
from selftest import make_synthetic as M  # noqa: E402


def step(name, args, env):
    t0 = time.time()
    print(f"\n----- {name} -----", flush=True)
    r = subprocess.run([sys.executable, str(HERE / args[0]), *args[1:]], env=env)
    ok = r.returncode == 0
    print(f"----- {name}: {'ok' if ok else 'FAILED'} ({time.time() - t0:.0f} s)", flush=True)
    return ok


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--keep", action="store_true", help="keep the synthetic files afterwards")
    a = ap.parse_args()
    pkg = Path(S.PACKAGE_OUTPUTS)
    if not (pkg / "Focused_ozone_evidence_2026_10_06").exists():
        sys.exit(f"PACKAGE_OUTPUTS does not point at the package outputs folder:\n  {pkg}\nEdit settings.py first.")
    root = Path(S.DATA_DIR) / "selftest"
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    env = os.environ.copy()
    env.update(PACKAGE_OUTPUTS=str(pkg), DATA_DIR=str(root / "data"), RESULTS_DIR=str(root / "results"),
               SWOOSH_FILE=str(root / "swoosh_synthetic.nc"), PYTHONIOENCODING="utf-8")
    winters = S.WINTERS
    results = {}

    print("Making synthetic MLS, ERA5 and SWOOSH files ...", flush=True)
    M.make_mls(root / "raw_mls", pkg, winters)
    M.make_wstar_months(root / "raw_wstar", pkg, winters)
    M.make_era5_radiation(root / "data" / "era5_radiation", S.RAD_YEARS)
    M.make_swoosh(root / "swoosh_synthetic.nc", pkg)

    results["01 reduce MLS files"] = step("01 reduce MLS files", ["01_download_mls.py", "--from-local-dir", str(root / "raw_mls")], env)
    results["02 N2O footprints"] = step("02 N2O footprints", ["02_build_n2o_footprints.py"], env)
    results["03 TEM reduction"] = step("03 TEM reduction", ["03_download_era5_wstar.py", "--from-local-dir", str(root / "raw_wstar")], env)
    results["04 w* index"] = step("04 w* index", ["04_build_wstar_index.py"], env)
    results["06a radiation inputs"] = step("06a radiation inputs", ["06a_prepare_radiation_inputs.py"], env)
    try:
        import climlab  # noqa: F401
        from climlab.radiation import RRTMG  # noqa: F401
        have_rrtmg = True
    except Exception:
        have_rrtmg = False
    if have_rrtmg:
        results["06b radiation"] = step("06b radiation", ["06b_run_radiation.py", str(root / "results" / "radiation_inputs.nc"),
                                                          "--out", str(root / "results" / "radiation")], env)
    else:
        print("\n06b skipped: climlab with RRTMG is not installed here (expected on Windows; use Colab or WSL).")
    results["07 transport tests"] = step("07 transport tests", ["07_transport_tests.py", "--permutations", "999"], env)
    results["03 request (dry run)"] = step("03 request (dry run)", ["03_download_era5_wstar.py", "--dry-run", "--pilot"], env)
    results["05 requests (dry run)"] = step("05 requests (dry run)", ["05_download_era5_radiation.py", "--dry-run"], env)

    print("\n================ SELF-TEST SUMMARY ================")
    for k, v in results.items():
        print(f"  {k:28s} {'PASS' if v else 'FAIL'}")
    if not have_rrtmg:
        print(f"  {'06b radiation':28s} skipped (needs Linux, macOS, WSL or Colab)")
    if not a.keep:
        shutil.rmtree(root, ignore_errors=True)
    sys.exit(0 if all(results.values()) else 1)


if __name__ == "__main__":
    main()
