"""Step 8. Full inference for the per-winter radiative experiment (Table S11 of the GRL Supporting Information).

Uses the per-winter predictions written by 06b (radiation_per_winter.csv) and
applies the paper's inference to all four region-pressure combinations:
classical, HAC and Freedman-Lane, each adjusted across the four regions
(Benjamini-Hochberg), with q_cons the largest of the three.

  python 08_post_subtraction.py
  python 08_post_subtraction.py --per-winter C:\\ENSO_mechanism_data\\results\\radiation\\radiation_per_winter.csv

Two tests:
  Observed on predicted     observed DJF temperature regressed on the predicted
                            radiative temperature; slope b (b = 1: equal amplitudes)
  Ozone after subtraction   observed minus predicted temperature regressed on
                            ozone; partial r compares with the principal model

Outputs in RESULTS_DIR: post_subtraction.csv, post_subtraction.md
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import settings as S  # noqa: E402
from common import COMMON, ensure_dirs, family, load_package_winter, log  # noqa: E402


def load(path):
    pw = pd.read_csv(path)
    pw = pw.rename(columns={"winter": "winter_year", "dT_radiative_transient": "dT_rad"})
    pw["p"] = pw.target_hpa.round(1)
    pk = load_package_winter()
    d = pk.merge(pw[["hemisphere", "p", "winter_year", "dT_rad", "t_obs", "o3_obs"]],
                 on=["hemisphere", "p", "winter_year"], how="left")
    ok = d.dT_rad.notna()
    dt = float(np.max(np.abs(d.t[ok] - d.t_obs[ok])))
    do = float(np.max(np.abs(d.ozone_anomaly_ppmv[ok] - d.o3_obs[ok])))
    log(f"Check against the package series: max |T difference| = {dt:.2e} K, max |ozone difference| = {do:.2e} ppmv")
    if dt > 1e-3 or do > 1e-5:
        sys.exit("The per-winter file does not match the package winter series. Check that 06b used the same inputs.")
    d["t_minus_rad"] = d.t - d.dT_rad
    return d


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--per-winter", default=str(Path(S.RESULTS_DIR) / "radiation" / "radiation_per_winter.csv"))
    ap.add_argument("--permutations", type=int, default=S.PERMUTATIONS)
    a = ap.parse_args()
    ensure_dirs()
    if not Path(a.per_winter).exists():
        sys.exit(f"Not found: {a.per_winter}. Run 06b first and unzip its results into RESULTS_DIR\\radiation.")
    d = load(a.per_winter)
    rng = np.random.default_rng(S.RANDOM_SEED)
    # Order fixed so that the permutation draws reproduce Table S11 with the default seed.
    base = family(d, COMMON, "Principal (reference)", y="t", rng=rng, B=a.permutations)
    after = family(d, COMMON, "Ozone after subtraction", y="t_minus_rad", rng=rng, B=a.permutations)
    pred = family(d, COMMON, "Observed on predicted", x="dT_rad", y="t", rng=rng, B=a.permutations)
    res = pd.concat([base, pred, after], ignore_index=True)
    out = Path(S.RESULTS_DIR)
    res.to_csv(out / "post_subtraction.csv", index=False)
    cols = [c for c in ["model", "region", "n", "df", "partial_r", "slope", "ci_lo", "ci_hi",
                        "q_classical", "q_HAC", "q_FL", "q_cons"] if c in res.columns]
    print(res[cols].round(4).to_string(index=False))
    lines = ["# Per-winter radiative experiment: four-region inference", "",
             f"Permutations: {a.permutations:,}. Each q adjusts the four regions within one test; q_cons is the largest.", "",
             "| Test | Region | n | df | Partial r | Slope (95% interval) | q_cons |", "|---|---|---|---|---|---|---|"]
    for _, r in res.iterrows():
        lines.append(f"| {r.model} | {r.region} | {r.n} | {r.df} | {r.partial_r:+.3f} | "
                     f"{r.slope:.2f} ({r.ci_lo:.2f} to {r.ci_hi:.2f}) | {r.q_cons:.4f} |")
    lines += ["", "Read b with its interval: an interval that includes 1 does not reject equal observed and predicted "
              "amplitudes. A post-subtraction association that does not pass q_cons < 0.05 is at most suggestive.", ""]
    (out / "post_subtraction.md").write_text("\n".join(lines), encoding="utf-8")
    log(f"Wrote {out / 'post_subtraction.md'}")


if __name__ == "__main__":
    main()
