"""Step 6b. Radiation calculation: how much temperature change can the observed ozone make?

Needs climlab with RRTMG (conda-forge packages climlab and climlab-rrtmg).
These have no Windows build, so run this one step on Linux, macOS, WSL or
Google Colab (see README). Input is the single file radiation_inputs.nc
written by 06a; nothing else is needed.

  python 06b_run_radiation.py radiation_inputs.nc --out radiation_results

What it computes for each footprint and level (68.1 and 100 hPa):
  1. Ozone heating sensitivity for the observed shape of the ozone anomaly
     (K/day per ppmv), including shortwave and longwave, all-sky and clear-sky.
  2. Local radiative damping time at the level.
  3. The temperature change ozone alone produces under fixed dynamical
     heating (FDH): at equilibrium, and as a step response in which the
     covariate-adjusted DJF anomaly profile, normalized to 1 ppmv at the
     target, is imposed as a constant perturbation from 1 September and
     temperature is averaged over December-February.
  4. The radiative response ratio: the step response divided by the observed
     conditional slope. Its range inverts the classical 95% slope interval,
     so it reflects slope uncertainty alone. It is a model-conditional ratio,
     not a causal fraction.
  5. A separate per-winter experiment driven by each winter's monthly
     September-February ozone anomaly profiles. Run 08_post_subtraction.py
     afterwards for the four-region inference on this experiment.

Column names fraction_transient and fraction_eq in radiation_summary.csv are
kept for compatibility; they hold response ratios.
"""
import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
import xarray as xr
from scipy import linalg, stats

try:
    import climlab
    from climlab.radiation import RRTMG
except Exception as e:  # pragma: no cover
    sys.exit("climlab with RRTMG is required for this step.\n"
             "Install with: mamba install -c conda-forge climlab climlab-rrtmg\n"
             f"({e})")

try:  # optional: use the toolkit settings when run from the toolkit folder
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import settings as _S
    DEFAULTS = dict(fdh_top=_S.RAD_FDH_TOP_OF_FIXED_HPA, o3_bottom=_S.RAD_OZONE_BOTTOM_HPA,
                    co2=_S.RAD_CO2_PPMV, ch4=_S.RAD_CH4_PPBV, n2o=_S.RAD_N2O_PPBV,
                    r_liq=_S.RAD_R_LIQ_MICRON, r_ice=_S.RAD_R_ICE_MICRON, s0=_S.RAD_SOLAR_CONSTANT)
except Exception:
    DEFAULTS = dict(fdh_top=125.0, o3_bottom=150.0, co2=400.0, ch4=1850.0, n2o=330.0,
                    r_liq=12.0, r_ice=40.0, s0=1361.0)

TARGETS = {68.1: 68.1292, 100.0: 100.0}
MONTH_DAYS = [30, 31, 30, 31, 31, 28]          # Sep, Oct, Nov, Dec, Jan, Feb
GRAV = 9.80665


# ---------------------------------------------------------------------------
# Column set-up
# ---------------------------------------------------------------------------
def fine_grid():
    top = np.exp(np.linspace(np.log(1.0), np.log(20.0), 12, endpoint=False))
    mid = np.exp(np.arange(np.log(20.0), np.log(300.0), 0.07))
    bot = np.exp(np.linspace(np.log(300.0), np.log(1000.0), 16))
    p = np.sort(np.concatenate([top, mid, bot]))
    for t in TARGETS.values():
        p = p[np.abs(np.log(p) - np.log(t)) > 0.025]
    return np.sort(np.concatenate([p, list(TARGETS.values())]))


def interp_lnp(p_new, p_old, v, log_values=False):
    o = np.argsort(p_old)
    x, y = np.log(p_old[o]), np.asarray(v, float)[o]
    if log_values:
        return np.exp(np.interp(np.log(p_new), x, np.log(np.maximum(y, 1e-12))))
    return np.interp(np.log(p_new), x, y)


def djf_insolation(lat_deg, s0):
    """DJF mean TOA insolation and insolation-weighted cosine of zenith angle."""
    phi = np.deg2rad(lat_deg)
    doys = np.r_[np.arange(335, 366), np.arange(1, 60)]
    q, w = [], []
    for d in doys:
        dec = np.deg2rad(23.44) * np.sin(2 * np.pi * (284 + d) / 365.0)
        fac = 1 + 0.033 * np.cos(2 * np.pi * d / 365.0)
        a, b = np.sin(phi) * np.sin(dec), np.cos(phi) * np.cos(dec)
        h0 = np.arccos(np.clip(-np.tan(phi) * np.tan(dec), -1, 1))
        i1 = 2 * (a * h0 + b * np.sin(h0))
        i2 = 2 * (a * a * h0 + 2 * a * b * np.sin(h0) + b * b * (h0 / 2 + np.sin(2 * h0) / 4))
        q.append(s0 * fac * i1 / (2 * np.pi))
        w.append(i2 / i1)
    q, w = np.array(q), np.array(w)
    return q.mean(), float((q * w).sum() / q.sum())


class Column:
    def __init__(self, ds, hemi, args):
        self.args = args
        self.p = fine_grid()
        sel = ds.sel(hemisphere=hemi)
        pe = ds.plev.values.astype(float)
        self.T = interp_lnp(self.p, pe, sel.T_bg.values)
        self.q = interp_lnp(self.p, pe, sel.q_bg.values, log_values=True)
        self.o3 = interp_lnp(self.p, pe, sel.o3_vmr_bg.values, log_values=True)
        cc = np.clip(interp_lnp(self.p, pe, sel.cc_bg.values), 0, 1)
        clwc = np.maximum(interp_lnp(self.p, pe, sel.clwc_bg.values), 0)
        ciwc = np.maximum(interp_lnp(self.p, pe, sel.ciwc_bg.values), 0)
        self.ts = float(sel.skt_bg)
        self.alb = float(sel.fal_bg)
        self.lat = float(sel.lat_centroid)
        self.insol, self.mu = djf_insolation(self.lat, args.s0)
        st = climlab.column_state(lev=self.p, water_depth=1.0)
        self.dp = np.asarray(st.Tatm.domain.axes["lev"].delta, float)
        cloudy = cc > 0.01
        path = lambda mix: mix * self.dp * 100.0 / GRAV * 1000.0  # g m-2 per layer
        self.cc = np.where(cloudy, cc, 0.0)
        self.clwp = np.where(cloudy, path(clwc) / np.maximum(cc, 0.01), 0.0)
        self.ciwp = np.where(cloudy, path(ciwc) / np.maximum(cc, 0.01), 0.0)

    def heating(self, T=None, o3=None, cloudy=True):
        st = climlab.column_state(lev=self.p, water_depth=1.0)
        st["Tatm"][:] = self.T if T is None else T
        st["Ts"][:] = self.ts
        a = self.args
        absorbers = dict(CO2=a.co2 * 1e-6, CH4=a.ch4 * 1e-9, N2O=a.n2o * 1e-9, O2=0.209,
                         CFC11=0.0, CFC12=0.0, CFC22=0.0, CCL4=0.0, O3=self.o3 if o3 is None else o3)
        kw = dict(state=st, specific_humidity=self.q, absorber_vmr=absorbers, S0=a.s0, coszen=self.mu,
                  irradiance_factor=self.insol / (a.s0 * self.mu), aldif=self.alb, aldir=self.alb,
                  asdif=self.alb, asdir=self.alb, r_liq=a.r_liq, r_ice=a.r_ice)
        if cloudy:
            kw.update(cldfrac=self.cc, clwp=self.clwp, ciwp=self.ciwp, icld=1)
        else:
            kw.update(cldfrac=0.0, clwp=0.0, ciwp=0.0, icld=0)
        rad = RRTMG(**kw)
        rad.compute_diagnostics()
        return np.asarray(rad.TdotSW, float) + np.asarray(rad.TdotLW, float)

    def jacobians(self, cloudy, t_levels, o_levels, dT=0.5, rel_o3=0.05):
        n = len(self.p)
        J = np.zeros((n, len(t_levels)))
        for c, k in enumerate(t_levels):
            Tp, Tm = self.T.copy(), self.T.copy()
            Tp[k] += dT
            Tm[k] -= dT
            J[:, c] = (self.heating(Tp, None, cloudy) - self.heating(Tm, None, cloudy)) / (2 * dT)
        G = np.zeros((n, len(o_levels)))
        for c, k in enumerate(o_levels):
            d = rel_o3 * self.o3[k]
            op, om = self.o3.copy(), self.o3.copy()
            op[k] += d
            om[k] -= d
            G[:, c] = (self.heating(None, op, cloudy) - self.heating(None, om, cloudy)) / (2 * d * 1e6)
        return J, G  # K/day per K ; K/day per ppmv


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------
def equilibrium(J, G, S_cols, S_rows, O_cols, d_o3):
    """FDH: solve J_SS dT_S = -G_S dO3 for the adjusted levels S."""
    A = J[np.ix_(S_rows, S_cols)]
    f = G[S_rows][:, O_cols] @ d_o3
    return np.linalg.solve(A, -f)


def transient(J, G, S_cols, S_rows, O_cols, monthly_d_o3):
    """Integrate dT/dt = J_SS dT + G_S dO3(t) daily from 1 September; return DJF mean."""
    A = J[np.ix_(S_rows, S_cols)]
    P = linalg.expm(A)
    Phi = np.linalg.solve(A, P - np.eye(len(A)))
    x = np.zeros(len(A))
    acc = np.zeros(len(A))
    for m, nd in enumerate(MONTH_DAYS):
        f = G[S_rows][:, O_cols] @ monthly_d_o3[m]
        for _ in range(nd):
            x = P @ x + Phi @ f
            if m >= 3:
                acc += x
    return acc / sum(MONTH_DAYS[3:])


def needed_levels(djf_ok, swl, o3_bottom, min_frac=0.9):
    """SWOOSH levels that shape the ozone perturbation at or above o3_bottom.

    Real SWOOSH has no tropical ozone at some levels (for example 316 hPa).
    A level is used when it has data in at least min_frac of the winters and
    lies above o3_bottom, plus the next level below for interpolation.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        frac = np.isfinite(djf_ok).mean(axis=0)
    return (frac >= min_frac) & (swl <= 1.25 * o3_bottom)


def residualize(y, C):
    b, *_ = np.linalg.lstsq(C, y, rcond=None)
    return y - C @ b


def design(cov, winters):
    names = list(cov.cov.values)
    X = cov.values.astype(float)
    nino = X[:, names.index("nino34")]
    X = np.column_stack([X, nino ** 2, np.asarray(winters) - 2015.0])
    X = (X - X.mean(0)) / X.std(0)
    return np.column_stack([np.ones(len(X)), X])


def ols_slope(y, x, C):
    X = np.column_stack([C, x])
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    e = y - X @ b
    df = len(y) - X.shape[1]
    se = np.sqrt(e @ e / df * np.linalg.inv(X.T @ X)[-1, -1])
    tc = stats.t.ppf(0.975, df)
    r = np.corrcoef(residualize(x, C), residualize(y, C))[0, 1]
    return dict(slope=b[-1], lo=b[-1] - tc * se, hi=b[-1] + tc * se, r=r,
                p=2 * stats.t.sf(abs(b[-1] / se), df), df=df)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("inputs", nargs="?", default="radiation_inputs.nc")
    ap.add_argument("--out", default="radiation_results")
    for k, v in DEFAULTS.items():
        ap.add_argument("--" + k.replace("_", "-"), type=float, default=v)
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    ds = xr.open_dataset(args.inputs)
    swl = ds.swoosh_level.values.astype(float)
    winters = ds.winter.values
    summary, profiles, perwinter = [], [], []

    for hemi in ds.hemisphere.values:
        col = Column(ds, hemi, args)
        p = col.p
        print(f"\n=== {hemi} footprint (centroid {col.lat:+.1f} deg) ===")
        q0 = col.heating()
        for t in TARGETS.values():
            k = int(np.argmin(np.abs(p - t)))
            print(f"  background at {t:6.1f} hPa: T = {col.T[k]:.1f} K, O3 = {col.o3[k] * 1e6:.3f} ppmv, "
                  f"net radiative heating = {q0[k]:+.2f} K/day")
        print(f"  DJF insolation {col.insol:.0f} W m-2, weighted cos(zenith) {col.mu:.2f}")
        t_levels = np.where(p <= 150.0 + 1e-6)[0]
        o_levels = np.where((p <= args.o3_bottom + 1e-6))[0]
        for sky in ("all-sky", "clear-sky"):
            J, G = col.jacobians(sky == "all-sky", t_levels, o_levels)
            for target_hpa, t in TARGETS.items():
                kt = int(np.argmin(np.abs(p - t)))
                ti = list(ds.target.values).index(target_hpa)
                hs = ds.sel(hemisphere=hemi)
                cov = hs.covariates.isel(target=ti)
                yo = hs.t_obs.isel(target=ti).values.astype(float)
                xo = hs.o3_obs.isel(target=ti).values.astype(float)
                ok = np.isfinite(yo) & np.isfinite(xo) & np.all(np.isfinite(cov.values), axis=1)
                C = design(cov[ok], winters[ok])
                obs = ols_slope(yo[ok], xo[ok], C)

                # Typical ozone anomaly shape per ppmv at the target (covariate-adjusted)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", RuntimeWarning)
                    djf = np.nanmean(hs.o3_anom_ppmv.values[:, 3:6, :], axis=1)  # winter x level
                ks = int(np.argmin(np.abs(swl - t)))
                need = needed_levels(djf[ok], swl, args.o3_bottom)
                if not need[ks]:
                    sys.exit(f"SWOOSH has too little ozone data at {swl[ks]:.1f} hPa in the {hemi} footprint.")
                if sky == "all-sky" and target_hpa == 68.1:
                    gaps = swl[(swl <= 1.25 * args.o3_bottom) & ~need]
                    if len(gaps):
                        print("  SWOOSH levels without enough data, left out: "
                              + ", ".join(f"{g:.0f} hPa" for g in gaps))
                good = ok & np.all(np.isfinite(djf[:, need]), axis=1)
                Cg = design(cov[good], winters[good])
                xt = residualize(djf[good, ks], Cg)
                lv = np.where(need)[0]
                shape_sw = np.array([np.dot(residualize(djf[good, j], Cg), xt) / np.dot(xt, xt) for j in lv])
                shape = interp_lnp(p, swl[lv], shape_sw)
                shape[(p > args.o3_bottom) | (p < swl[lv].min()) | (p > swl[lv].max())] = 0.0
                d_unit = shape[o_levels]
                dq_unit = G[:, :] @ d_unit
                beta_eff = dq_unit[kt]
                # purely local bump (about 1 km) for comparison with published beta
                bump = np.exp(-0.5 * ((np.log(p) - np.log(t)) / 0.07) ** 2)
                beta_local = (G @ bump[o_levels])[kt]

                for top in (100.0, 125.0, 150.0):
                    S_rows = np.where(p <= top + 1e-6)[0]
                    S_cols = np.searchsorted(t_levels, S_rows)
                    S_rows_J = S_rows
                    if kt not in S_rows:
                        continue
                    dT_eq = equilibrium(J, G, S_cols, S_rows_J, slice(None), d_unit)
                    dT_tr = transient(J, G, S_cols, S_rows_J, slice(None), [d_unit] * 6)
                    pos = int(np.where(S_rows == kt)[0][0])
                    M_eq, M_tr = dT_eq[pos], dT_tr[pos]
                    row = dict(hemisphere=hemi, target_hpa=target_hpa, sky=sky, fdh_top_hpa=top,
                               beta_shape_K_day_ppmv=beta_eff, beta_local_K_day_ppmv=beta_local,
                               tau_effective_days=M_eq / beta_eff,
                               M_obs=obs["slope"], M_obs_lo=obs["lo"], M_obs_hi=obs["hi"],
                               M_eq=M_eq, M_transient=M_tr,
                               fraction_eq=M_eq / obs["slope"],
                               fraction_eq_range=f"{M_eq / obs['hi']:.2f}-{M_eq / obs['lo']:.2f}" if obs["lo"] > 0 else "",
                               fraction_transient=M_tr / obs["slope"],
                               fraction_transient_range=f"{M_tr / obs['hi']:.2f}-{M_tr / obs['lo']:.2f}" if obs["lo"] > 0 else "")
                    if top == args.fdh_top:
                        # per-winter radiative prediction from the actual monthly ozone anomalies
                        pred = np.full(len(winters), np.nan)
                        for j in range(len(winters)):
                            mo = ds.sel(hemisphere=hemi).o3_anom_ppmv.values[j]
                            if not np.all(np.isfinite(mo[3:6, ks])):
                                continue
                            mon = []
                            for m in range(6):
                                f = need & np.isfinite(mo[m])
                                if f.sum() < 2:
                                    mon.append(np.zeros(len(o_levels)))
                                    continue
                                prof = interp_lnp(p, swl[f], mo[m][f])
                                prof[(p > args.o3_bottom) | (p < swl[f].min()) | (p > swl[f].max())] = 0.0
                                mon.append(prof[o_levels])
                            pred[j] = transient(J, G, S_cols, S_rows_J, slice(None), mon)[pos]
                        okp = ok & np.isfinite(pred)
                        Cp = design(cov[okp], winters[okp])
                        fitp = ols_slope(yo[okp], pred[okp], Cp)
                        after = ols_slope(yo[okp] - pred[okp], xo[okp], Cp)
                        row.update(per_winter_b=fitp["slope"], per_winter_b_lo=fitp["lo"],
                                   per_winter_b_hi=fitp["hi"], partial_r_predicted=fitp["r"],
                                   ozone_partial_r_after_removing_radiation=after["r"],
                                   ozone_p_after_removing_radiation=after["p"],
                                   ozone_partial_r_before=obs["r"])
                        if sky == "all-sky":
                            for j in np.where(okp)[0]:
                                perwinter.append(dict(hemisphere=hemi, target_hpa=target_hpa,
                                                      winter=int(winters[j]), t_obs=yo[j], o3_obs=xo[j],
                                                      dT_radiative_transient=pred[j]))
                            dT_eq_full = np.zeros_like(p)
                            dT_eq_full[S_rows] = dT_eq
                            for i in range(len(p)):
                                profiles.append(dict(hemisphere=hemi, target_hpa=target_hpa, p_hpa=p[i],
                                                     ozone_shape=shape[i], dQ_K_day_per_ppmv=dq_unit[i],
                                                     dT_eq_K_per_ppmv=dT_eq_full[i], T_bg=col.T[i],
                                                     o3_bg_ppmv=col.o3[i] * 1e6, Q_bg=q0[i]))
                    summary.append(row)
                print(f"  {sky:9s} {target_hpa:5.1f} hPa: beta(shape) {beta_eff:.2f}, beta(local) {beta_local:.2f} K/day/ppmv")

    import pandas as pd
    sm = pd.DataFrame(summary)
    sm.to_csv(out / "radiation_summary.csv", index=False)
    pd.DataFrame(profiles).to_csv(out / "radiation_profiles.csv", index=False)
    pd.DataFrame(perwinter).to_csv(out / "radiation_per_winter.csv", index=False)
    write_report(sm, out, args)
    try:
        make_figure(pd.DataFrame(profiles), sm, out, args)
    except Exception as e:
        print("Figure skipped:", e)
    print(f"\nResults written to {out.resolve()}")


def verdict(f):
    if not np.isfinite(f):
        return "not determined"
    if f >= 1.0:
        return ("under these model assumptions the prescribed ozone perturbation produces a response at least as large "
                "as the observed slope")
    return ("under these model assumptions the prescribed ozone perturbation produces a smaller response than the "
            "observed slope; this ratio does not by itself identify what produces the rest")


def write_report(sm, out, args):
    lines = ["# Radiation calculation: summary", "",
             f"Fixed dynamical heating above {args.fdh_top:.0f} hPa; ozone anomalies below "
             f"{args.o3_bottom:.0f} hPa set to zero. RRTMG via climlab.", ""]
    main = sm[(sm.sky == "all-sky") & (sm.fdh_top_hpa == args.fdh_top)]
    for _, r in main.iterrows():
        principal = (r.hemisphere, r.target_hpa) in [("south", 68.1), ("north", 100.0)]
        lines += [f"## {r.hemisphere.title()} {r.target_hpa:.1f} hPa{' (principal region)' if principal else ''}", "",
                  f"- Observed slope: {r.M_obs:.1f} K/ppmv (95% {r.M_obs_lo:.1f} to {r.M_obs_hi:.1f}).",
                  f"- Ozone heating sensitivity for the observed anomaly shape: {r.beta_shape_K_day_ppmv:.2f} K/day/ppmv "
                  f"(thin layer at the level: {r.beta_local_K_day_ppmv:.2f}).",
                  f"- Effective radiative balance time for this shape (M_eq / beta): {r.tau_effective_days:.0f} days. "
                  f"The paper's slope would need {r.M_obs / r.beta_shape_K_day_ppmv:.0f} days.",
                  f"- Radiative temperature response per ppmv: {r.M_transient:.1f} K (step response from 1 September, DJF mean), "
                  f"{r.M_eq:.1f} K at full equilibrium.",
                  f"- Radiative response ratio (step response / observed conditional slope): {r.fraction_transient:.2f} "
                  f"(range from slope uncertainty alone {r.fraction_transient_range or 'n/a'}); equilibrium ratio "
                  f"{r.fraction_eq:.2f}.",
                  f"- Per-winter test: observed T on predicted radiative T gives b = {r.per_winter_b:.2f} "
                  f"({r.per_winter_b_lo:.2f} to {r.per_winter_b_hi:.2f}); b near 1 means the prediction has the right size.",
                  f"- Ozone partial r before / after subtracting the predicted radiative temperature: "
                  f"{r.ozone_partial_r_before:.2f} / {r.ozone_partial_r_after_removing_radiation:.2f} "
                  f"(unadjusted p after = {r.ozone_p_after_removing_radiation:.3f}; run 08_post_subtraction.py for four-region q).",
                  f"- Reading: {verdict(r.fraction_transient) if r.M_obs_lo > 0 else 'the observed slope is not distinguishable from zero, so the ratio is not meaningful'}.", ""]
    lines += ["## Sensitivity", "", "Response ratio (step response) by sky and FDH boundary:", "",
              "| Region | Sky | FDH top 100 | 125 | 150 |", "|---|---|---|---|---|"]
    for (h, t, sky), g in sm.groupby(["hemisphere", "target_hpa", "sky"]):
        vals = {row.fdh_top_hpa: f"{row.fraction_transient:.2f}" for _, row in g.iterrows()}
        lines.append(f"| {h} {t} | {sky} | {vals.get(100.0, '-')} | {vals.get(125.0, '-')} | {vals.get(150.0, '-')} |")
    (out / "radiation_summary.md").write_text("\n".join(lines), encoding="utf-8")


def make_figure(pr, sm, out, args):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(2, 2, figsize=(8.3, 7.0), sharey=True)
    for i, (h, t) in enumerate([("south", 68.1), ("north", 100.0)]):
        g = pr[(pr.hemisphere == h) & (pr.target_hpa == t)]
        r = sm[(sm.hemisphere == h) & (sm.target_hpa == t) & (sm.sky == "all-sky") & (sm.fdh_top_hpa == args.fdh_top)].iloc[0]
        ax = axs[i, 0]
        ax.plot(g.dQ_K_day_per_ppmv, g.p_hpa, color="#1f4e79")
        ax.axvline(0, color="#bbbbbb", lw=0.8)
        ax.set_title(f"{'ac'[i]}  {h.title()} {t} hPa: heating change", loc="left", fontsize=11)
        ax.set_xlabel("K/day per ppmv at target")
        ax = axs[i, 1]
        ax.plot(g.dT_eq_K_per_ppmv, g.p_hpa, color="#8c8c8c", label="Equilibrium (FDH)")
        ax.errorbar([r.M_obs], [TARGETS[t]], xerr=[[r.M_obs - r.M_obs_lo], [r.M_obs_hi - r.M_obs]], fmt="o",
                    color="#1f4e79", label="Observed slope")
        ax.plot([r.M_transient], [TARGETS[t]], "s", color="#b5402f", label="Radiative, Sep-start")
        ax.axvline(0, color="#bbbbbb", lw=0.8)
        ax.set_title(f"{'bd'[i]}  Temperature per ppmv", loc="left", fontsize=11)
        ax.set_xlabel("K per ppmv")
        if i == 0:
            ax.legend(frameon=False, fontsize=8.5)
    for ax in axs[:, 0]:
        ax.set_ylabel("Pressure (hPa)")
    from matplotlib.ticker import NullFormatter, ScalarFormatter
    for ax in axs.flat:
        ax.set_yscale("log")
        ax.set_ylim(200, 20)
        ax.set_yticks([200, 150, 100, 70, 50, 30, 20])
        ax.yaxis.set_major_formatter(ScalarFormatter())
        ax.yaxis.set_minor_formatter(NullFormatter())
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out / "radiation_response.png", dpi=200)


if __name__ == "__main__":
    main()
