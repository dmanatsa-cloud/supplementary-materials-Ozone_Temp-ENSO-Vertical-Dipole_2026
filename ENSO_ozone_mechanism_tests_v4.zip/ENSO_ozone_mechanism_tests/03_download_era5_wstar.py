"""Step 3. Download ERA5 6-hourly v, T and omega and reduce each month to TEM w*.

One request per DJF month (63 in total). Each month is about 60-100 MB.
It is reduced to monthly zonal-mean TEM terms (a few kilobytes) and the
raw file is then deleted. Finished months are skipped on a rerun.

  python 03_download_era5_wstar.py --pilot     # 3 winters (9 requests)
  python 03_download_era5_wstar.py             # all 21 winters
  python 03_download_era5_wstar.py --dry-run   # print the first request only
  python 03_download_era5_wstar.py --from-local-dir D:\\era5_wstar   # files named YYYYMM.nc
"""
import argparse
import calendar
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402

import settings as S  # noqa: E402
from common import djf_months, ensure_dirs, log  # noqa: E402
from tem import monthly_tem  # noqa: E402

DATASET = "reanalysis-era5-pressure-levels"


def request(year, month):
    ndays = calendar.monthrange(year, month)[1]
    return {
        "product_type": ["reanalysis"],
        "variable": ["temperature", "v_component_of_wind", "vertical_velocity"],
        "year": [str(year)],
        "month": [f"{month:02d}"],
        "day": [f"{d:02d}" for d in range(1, ndays + 1)],
        "time": S.WSTAR_TIMES,
        "pressure_level": [str(p) for p in S.WSTAR_LEVELS_HPA],
        "data_format": "netcdf",
        "download_format": "unarchived",
        "area": S.WSTAR_AREA,
        "grid": [S.WSTAR_GRID_DEG, S.WSTAR_GRID_DEG],
    }


def reduce_and_save(raw, out):
    t = monthly_tem(raw)
    np.savez_compressed(out, **{k: np.asarray(v) for k, v in t.items()})
    return t


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pilot", action="store_true")
    ap.add_argument("--winters", type=int, nargs="*")
    ap.add_argument("--keep-raw", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--from-local-dir", help="reduce existing files named YYYYMM.nc")
    a = ap.parse_args()
    ensure_dirs()
    base = Path(S.DATA_DIR) / "era5_wstar"
    rawdir, reddir = base / "raw", base / "reduced"
    rawdir.mkdir(parents=True, exist_ok=True)
    reddir.mkdir(parents=True, exist_ok=True)
    winters = a.winters or (S.PILOT_WINTERS if a.pilot else S.WINTERS)
    months = [ym for w in winters for ym in djf_months(w)]

    if a.dry_run:
        print(json.dumps(request(*months[0]), indent=1))
        print(f"{len(months)} requests like this one would be sent.")
        return
    if a.from_local_dir:
        for y, m in months:
            src = Path(a.from_local_dir) / f"{y}{m:02d}.nc"
            out = reddir / f"{y}{m:02d}.npz"
            if src.exists() and not out.exists():
                reduce_and_save(src, out)
                log(f"reduced {src.name}")
        return

    import cdsapi
    client = cdsapi.Client()
    for i, (y, m) in enumerate(months, 1):
        out = reddir / f"{y}{m:02d}.npz"
        if out.exists():
            continue
        raw = rawdir / f"{y}{m:02d}.nc"
        for attempt in range(1, 4):
            if raw.exists():
                break
            try:
                log(f"[{i}/{len(months)}] requesting {y}-{m:02d} (the CDS queue can take a while)")
                client.retrieve(DATASET, request(y, m), str(raw))
            except Exception as e:
                log(f"  {y}-{m:02d} download attempt {attempt} failed: {e}")
                raw.unlink(missing_ok=True)
                time.sleep(30 * attempt)
        if not raw.exists():
            log(f"  {y}-{m:02d} skipped after 3 attempts; rerun later")
            continue
        try:
            t = reduce_and_save(raw, out)
        except Exception as e:
            log(f"  {y}-{m:02d} downloaded but could not be reduced ({e}). The raw file is kept: {raw}")
            continue
        band = (t["latitude"] >= -20) & (t["latitude"] <= 20)
        k70 = int(np.argmin(np.abs(t["level_hpa"] - 70)))
        val = np.average(t["wstar_mm_s"][k70, band], weights=np.cos(np.deg2rad(t["latitude"][band])))
        log(f"[{i}/{len(months)}] {y}-{m:02d} done; 20S-20N w* at 70 hPa = {val:.3f} mm/s")
        if not a.keep_raw:
            raw.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
