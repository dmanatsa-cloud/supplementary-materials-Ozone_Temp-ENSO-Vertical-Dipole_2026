"""Step 2. Turn the reduced MLS profiles into footprint winter anomalies.

MLS profiles are binned onto the native SWOOSH cells (5 degrees latitude by
20 degrees longitude, centred at 210 and 230 E), averaged by month, turned
into per-cell anomalies and then combined with exactly the footprint
weights used for SWOOSH ozone in the paper. The N2O series is therefore
sampled the same way as the ozone it is meant to control.

  python 02_build_n2o_footprints.py               # N2O
  python 02_build_n2o_footprints.py --product O3  # optional MLS ozone check

Outputs (in RESULTS_DIR)
  N2O_footprint_monthly.csv, N2O_footprint_winter.csv
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import settings as S  # noqa: E402
from common import (SWOOSH_LEVELS, TARGET_LEVELS, ensure_dirs, load_package_winter, log,  # noqa: E402
                    swoosh_cell_weights)


def load_profiles(product):
    folder = Path(S.DATA_DIR) / "mls" / product
    files = sorted(folder.glob("*.csv.gz"))
    if not files:
        sys.exit(f"No reduced MLS files in {folder}. Run 01_download_mls.py first.")
    parts = [pd.read_csv(f) for f in files]
    d = pd.concat([p for p in parts if len(p)], ignore_index=True)
    log(f"{len(files)} days, {len(d):,} screened values")
    d["date"] = pd.to_datetime(d.date)
    d["year"], d["month"] = d.date.dt.year, d.date.dt.month
    d = d[d.month.isin([12, 1, 2])].copy()
    d["winter_year"] = np.where(d.month == 12, d.year + 1, d.year)
    d = d[d.winter_year.isin(S.WINTERS)]
    # snap MLS pressures to the SWOOSH (12 per decade) levels
    lp = np.log(d.pressure_hpa.to_numpy())
    k = np.argmin(np.abs(lp[:, None] - np.log(SWOOSH_LEVELS)[None, :]), axis=1)
    d["level"] = SWOOSH_LEVELS[k]
    d = d[np.abs(lp - np.log(d.level.to_numpy())) < 0.03]
    d["lat_center"] = np.floor(d.lat / 5.0) * 5.0 + 2.5
    d["lon_center"] = np.where(d.lon < 220, 210.0, 230.0)
    return d


def build(product):
    d = load_profiles(product)
    cell = (d.groupby(["winter_year", "year", "month", "level", "lat_center", "lon_center"])
            .agg(value=("value", "mean"), n=("value", "size")).reset_index())
    cell.loc[cell.n < S.MLS_MIN_PROFILES_PER_CELL_MONTH, "value"] = np.nan
    clim = cell.groupby(["month", "level", "lat_center", "lon_center"]).value.mean().rename("clim")
    cell = cell.join(clim, on=["month", "level", "lat_center", "lon_center"])
    cell["anom"] = cell.value - cell.clim

    rows = []
    for hemi in ("south", "north"):
        w = swoosh_cell_weights(S.MASK, hemi)
        for (wy, y, m, lev), g in cell.groupby(["winter_year", "year", "month", "level"]):
            m_ = w.merge(g, on=["lat_center", "lon_center"], how="left")
            ok = m_.anom.notna()
            cover = m_.weight[ok].sum()
            val = (m_.weight[ok] * m_.anom[ok]).sum() / cover if cover >= 0.8 else np.nan
            absval = (m_.weight[ok] * m_.value[ok]).sum() / cover if cover >= 0.8 else np.nan
            rows.append(dict(winter_year=wy, year=y, month=m, hemisphere=hemi, level=lev,
                             anomaly=val, mean_value=absval, coverage=cover,
                             n_profiles=int(m_.n[ok].sum())))
    mon = pd.DataFrame(rows)
    full = mon.groupby(["winter_year", "hemisphere", "level"]).agg(
        anomaly=("anomaly", "mean"), months=("anomaly", "count"),
        n_profiles_min=("n_profiles", "min"), coverage_min=("coverage", "min"),
        mean_value=("mean_value", "mean")).reset_index()
    full.loc[full.months < 3, "anomaly"] = np.nan
    full["pressure_hpa"] = full.level.map(lambda v: TARGET_LEVELS.get(round(v, 1), v))
    full["p"] = full.level.round(1)
    unit = S.MLS_SCREENING[product]["unit"]
    col = f"{product.lower()}_anomaly_{unit}"
    full = full.rename(columns={"anomaly": col})
    mon = mon.rename(columns={"anomaly": col})
    return mon, full, col


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--product", default="N2O", choices=["N2O", "O3"])
    a = ap.parse_args()
    ensure_dirs()
    mon, win, col = build(a.product)
    out = Path(S.RESULTS_DIR)
    mon.to_csv(out / f"{a.product}_footprint_monthly.csv", index=False)
    win.to_csv(out / f"{a.product}_footprint_winter.csv", index=False)
    log(f"Wrote {out / (a.product + '_footprint_winter.csv')}")

    # Quick checks against the paper's SWOOSH ozone series
    pk = load_package_winter()
    m = pk.merge(win[["winter_year", "hemisphere", "p", col, "n_profiles_min"]],
                 on=["winter_year", "hemisphere", "p"], how="inner")
    if m.empty:
        log("No overlap with the package winters; check WINTERS and the downloads.")
        return
    print()
    print(f"{'region':14s} {'winters':>7s} {'r with SWOOSH ozone':>20s} {'min profiles/month':>19s}")
    for (h, p), g in m.groupby(["hemisphere", "p"]):
        g = g.dropna(subset=[col])
        r = np.corrcoef(g[col], g.ozone_anomaly_ppmv)[0, 1] if len(g) > 2 else np.nan
        print(f"{h + ' ' + str(p):14s} {len(g):7d} {r:20.2f} {int(g.n_profiles_min.min()):19d}")
    if a.product == "O3":
        print("\nMLS ozone should track SWOOSH closely (r above about 0.9). Lower values point to a binning problem.")
    else:
        print("\nN2O usually anti-correlates with ozone here, because both are moved by vertical transport.")
    thin = win[(win.n_profiles_min < 200) & win[col].notna() & win.p.isin([68.1, 100.0])]
    if len(thin):
        print("\nWinters with few profiles in at least one month (190 GHz duty cycling or outages):")
        print(thin[["winter_year", "hemisphere", "p", "n_profiles_min"]].drop_duplicates(["winter_year"]).to_string(index=False))


if __name__ == "__main__":
    main()
