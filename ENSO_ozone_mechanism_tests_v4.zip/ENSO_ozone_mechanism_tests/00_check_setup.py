"""Step 0. Check the Python packages, paths, logins and disk space.

  python 00_check_setup.py            # local checks only
  python 00_check_setup.py --online   # also logs in to NASA Earthdata and finds one MLS file
"""
import argparse
import importlib
import platform
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import settings as S  # noqa: E402

OK, BAD, WARN = "ok  ", "FAIL", "warn"


def line(status, msg):
    print(f"  [{status}] {msg}")
    return status != BAD


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--online", action="store_true")
    a = ap.parse_args()
    good = True
    print(f"Python {platform.python_version()} on {platform.system()}")

    print("\nPackages")
    for m in ["numpy", "scipy", "pandas", "xarray", "netCDF4", "h5py", "matplotlib", "cdsapi", "earthaccess"]:
        try:
            mod = importlib.import_module(m)
            good &= line(OK, f"{m} {getattr(mod, '__version__', '')}")
        except Exception as e:
            good &= line(BAD, f"{m} missing ({e.__class__.__name__}); create the environment from environment.yml")
    try:
        from climlab.radiation import RRTMG  # noqa: F401
        line(OK, "climlab with RRTMG (step 6b can run here)")
    except Exception:
        line(WARN, "climlab/RRTMG not available: run step 6b in Google Colab or WSL (README, step 6)")

    print("\nPaths in settings.py")
    p = Path(S.PACKAGE_OUTPUTS)
    good &= line(OK if (p / "Focused_ozone_evidence_2026_10_06").exists() else BAD, f"PACKAGE_OUTPUTS {p}")
    good &= line(OK if Path(S.SWOOSH_FILE).exists() else BAD, f"SWOOSH_FILE {S.SWOOSH_FILE}")
    d = Path(S.DATA_DIR)
    try:
        d.mkdir(parents=True, exist_ok=True)
        (d / ".write_test").write_text("x")
        (d / ".write_test").unlink()
        good &= line(OK, f"DATA_DIR {d} is writable")
    except Exception as e:
        good &= line(BAD, f"DATA_DIR {d} is not writable ({e})")
    if "onedrive" in str(d).lower():
        line(WARN, "DATA_DIR is inside OneDrive; move it (OneDrive will try to sync gigabytes)")
    free = shutil.disk_usage(d).free / 1e9
    line(OK if free > 20 else WARN, f"{free:.0f} GB free on the DATA_DIR drive (20 GB recommended)")

    print("\nLogins")
    home = Path.home()
    netrc = [home / ".netrc", home / "_netrc"]
    line(OK if any(f.exists() for f in netrc) else WARN,
         "NASA Earthdata credentials file " + ("found" if any(f.exists() for f in netrc)
                                                else "not found yet (step 1 will ask for your login once and save it)"))
    rc = home / ".cdsapirc"
    if rc.exists():
        txt = rc.read_text()
        good &= line(OK if "cds.climate.copernicus.eu/api" in txt else BAD,
                     f"{rc} " + ("points to the current CDS API" if "cds.climate.copernicus.eu/api" in txt
                                  else "must contain  url: https://cds.climate.copernicus.eu/api"))
    else:
        good &= line(BAD, f"{rc} not found; create it (README, step 2)")

    if a.online:
        print("\nOnline check")
        try:
            import earthaccess
            auth = earthaccess.login(persist=True)
            g = earthaccess.search_data(short_name="ML2N2O", version=S.MLS_VERSION,
                                        temporal=("2010-01-01", "2010-01-01T23:59:59"))
            line(OK if g else BAD, f"Earthdata login works; ML2N2O v{S.MLS_VERSION} files found: {len(g)}")
        except Exception as e:
            good &= line(BAD, f"Earthdata check failed: {e}")

    print("\nAll required checks passed." if good else "\nFix the FAIL lines above, then run this again.")
    sys.exit(0 if good else 1)


if __name__ == "__main__":
    main()
