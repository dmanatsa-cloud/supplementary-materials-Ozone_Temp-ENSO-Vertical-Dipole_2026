"""Transformed Eulerian mean (TEM) residual vertical velocity from ERA5 pressure-level fields.

In pressure coordinates (Andrews, Holton and Leovy, 1987):
    omega* = omega_bar + 1/(a cos(phi)) d/dphi [ cos(phi) v'theta' / dtheta_bar/dp ]
    w*     = -(H / p) omega*          (log-pressure vertical velocity, H = 7 km)
Overbars are zonal means and primes are departures from them. Eddy fluxes
are formed from each 6-hourly field and then averaged, as in standard TEM
products.
"""
import numpy as np
import xarray as xr

A_EARTH = 6.371e6
H_SCALE = 7000.0
KAPPA = 0.2857


def open_era5(path):
    ds = xr.open_dataset(path)
    ren = {}
    for old, new in [("valid_time", "time"), ("pressure_level", "level"), ("isobaricInhPa", "level"),
                     ("lat", "latitude"), ("lon", "longitude")]:
        if old in ds.dims or old in ds.coords:
            ren[old] = new
    ds = ds.rename(ren)
    for v in ("number", "expver"):
        if v in ds.coords and v not in ds.dims:
            ds = ds.drop_vars(v)
    if "longitude" in ds.dims:
        ds = ds.assign_coords(longitude=ds.longitude % 360).drop_duplicates("longitude").sortby("longitude")
    return ds.sortby("latitude")


def _var(ds, *names):
    for n in names:
        if n in ds:
            return ds[n]
    raise KeyError(f"None of {names} in file; variables are {list(ds.data_vars)}")


def monthly_tem(path, chunk=16):
    """Monthly-mean zonal-mean TEM terms on the file's latitudes and levels."""
    ds = open_era5(path)
    T = _var(ds, "t", "temperature")
    v = _var(ds, "v", "v_component_of_wind")
    w = _var(ds, "w", "vertical_velocity")
    nlon = ds.sizes["longitude"]
    span = float(ds.longitude.max() - ds.longitude.min())
    if span < 350:
        raise ValueError(f"TEM needs all longitudes; this file spans only {span:.0f} degrees.")
    lev = ds.level.values.astype(float)
    p = lev * 100.0
    lat = ds.latitude.values.astype(float)
    phi = np.deg2rad(lat)
    cosphi = np.cos(phi)
    nt = ds.sizes["time"]
    acc = {k: np.zeros((len(lev), len(lat))) for k in ("omega_bar", "omega_star", "vtheta", "dthdp")}
    for s in range(0, nt, chunk):
        sl = slice(s, min(nt, s + chunk))
        Tt = T.isel(time=sl).transpose("time", "level", "latitude", "longitude").values.astype(float)
        vt = v.isel(time=sl).transpose("time", "level", "latitude", "longitude").values.astype(float)
        wt = w.isel(time=sl).transpose("time", "level", "latitude", "longitude").values.astype(float)
        theta = Tt * (1.0e5 / p)[None, :, None, None] ** KAPPA
        thbar = theta.mean(-1)
        vbar = vt.mean(-1)
        vth = ((vt - vbar[..., None]) * (theta - thbar[..., None])).mean(-1)
        dthdp = np.gradient(thbar, p, axis=1)
        F = cosphi[None, None, :] * vth / dthdp
        dF = np.gradient(F, phi, axis=2)
        ostar = wt.mean(-1) + dF / (A_EARTH * cosphi[None, None, :])
        acc["omega_bar"] += wt.mean(-1).sum(0)
        acc["omega_star"] += ostar.sum(0)
        acc["vtheta"] += vth.sum(0)
        acc["dthdp"] += dthdp.sum(0)
    out = {k: a / nt for k, a in acc.items()}
    out["wstar_mm_s"] = -(H_SCALE / p)[:, None] * out["omega_star"] * 1000.0
    out["wbar_mm_s"] = -(H_SCALE / p)[:, None] * out["omega_bar"] * 1000.0
    out["latitude"] = lat
    out["level_hpa"] = lev
    out["n_times"] = nt
    out["n_lon"] = nlon
    ds.close()
    return out


def band_mean(field, lat, lo, hi):
    sel = (lat >= lo) & (lat <= hi)
    wts = np.cos(np.deg2rad(lat[sel]))
    return (field[..., sel] * wts).sum(-1) / wts.sum()
