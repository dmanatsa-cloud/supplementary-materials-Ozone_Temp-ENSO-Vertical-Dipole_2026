"""Step 6a. Build the single small input file for the radiation calculation.

Runs on Windows. It gathers, for each footprint:
  - the DJF 2005-2025 mean ERA5 column (T, humidity, ozone, clouds, surface),
  - SWOOSH ozone anomaly profiles for September to February of every winter,
    sampled with the paper's footprint weights,
  - the paper's winter temperature, ozone and covariate series.
It writes RESULTS_DIR/radiation_inputs.nc (well under 1 MB), which is the
only file the radiation step (06b) needs.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import xarray as xr  # noqa: E402

import settings as S  # noqa: E402
from common import (COMMON, ensure_dirs, footprint_weights, load_package_winter, log,  # noqa: E402
                    read_swoosh_cells, swoosh_cell_weights, swoosh_footprint_anomalies)
from tem import open_era5  # noqa: E402

M_AIR, M_O3 = 28.9644, 47.9982
PL = {"t": "pl_temperature.nc", "q": "pl_specific_humidity.nc", "o3": "pl_ozone_mass_mixing_ratio.nc",
      "cc": "pl_fraction_of_cloud_cover.nc", "clwc": "pl_specific_cloud_liquid_water_content.nc",
      "ciwc": "pl_specific_cloud_ice_water_content.nc"}
SL = {"skt": ("skt", "skin_temperature"), "sp": ("sp", "surface_pressure"), "fal": ("fal", "forecast_albedo")}
HEMIS = ["south", "north"]
MONTH6 = [9, 10, 11, 12, 1, 2]


def winter_coord(ds):
    t = pd.to_datetime(ds.time.values)
    winter = np.where(t.month == 12, t.year + 1, t.year)
    keep = np.isin(t.month, [12, 1, 2]) & np.isin(winter, S.WINTERS)
    return ds.isel(time=np.where(keep)[0])


def on_footprint_grid(da, lat, lon):
    da = da.assign_coords(longitude=(da.longitude % 360)).sortby("longitude").sortby("latitude")
    da = da.sel(latitude=lat, longitude=lon, method="nearest", tolerance=0.01)
    return da


def footprint_profile(da, w):
    """Weighted footprint mean, then mean over all DJF months."""
    wa = xr.DataArray(w, dims=("latitude", "longitude"))
    return float_or_array((da * wa).sum(("latitude", "longitude")).mean("time"))


def float_or_array(x):
    v = np.asarray(x.values, float)
    return v.item() if v.ndim == 0 else v


def main():
    ensure_dirs()
    src = Path(S.DATA_DIR) / "era5_radiation"
    lat, lon, _ = footprint_weights(S.MASK, "south")
    wts = {h: footprint_weights(S.MASK, h)[2] for h in HEMIS}

    prof = {h: {} for h in HEMIS}
    plev = None
    for key, fname in PL.items():
        f = src / fname
        if not f.exists():
            sys.exit(f"Missing {f}. Run 05_download_era5_radiation.py first.")
        ds = winter_coord(open_era5(f))
        var = next(v for v in ds.data_vars if {"level", "latitude", "longitude"} <= set(ds[v].dims))
        da = on_footprint_grid(ds[var], lat, lon).transpose("time", "level", "latitude", "longitude")
        plev = da.level.values.astype(float)
        for h in HEMIS:
            prof[h][key] = footprint_profile(da, wts[h])
        log(f"{fname}: {ds.sizes['time']} DJF months")
    ds = winter_coord(open_era5(src / "sl_surface.nc"))
    for key, names in SL.items():
        var = next(n for n in names if n in ds)
        da = on_footprint_grid(ds[var], lat, lon)
        for h in HEMIS:
            prof[h][key] = footprint_profile(da, wts[h])

    # SWOOSH ozone anomaly profiles, September to February of each winter
    sw = read_swoosh_cells()
    swl = sw["level"]
    o3m = np.full((2, len(S.WINTERS), 6, len(swl)), np.nan)
    for i, h in enumerate(HEMIS):
        cells = swoosh_cell_weights(S.MASK, h)
        keys = [(w - 1 if m >= 9 else w, m) for w in S.WINTERS for m in MONTH6]
        an = swoosh_footprint_anomalies(sw, cells, keys)
        for j, w in enumerate(S.WINTERS):
            for k, m in enumerate(MONTH6):
                o3m[i, j, k] = an[(w - 1 if m >= 9 else w, m)]

    # Paper series for the regression comparison
    pk = load_package_winter()
    targets = [68.1, 100.0]
    covs = [c for c in COMMON if c not in ("nino34_sq", "trend")]
    t_obs = np.full((2, 2, len(S.WINTERS)), np.nan)
    o3_obs = np.full_like(t_obs, np.nan)
    cov = np.full((2, 2, len(S.WINTERS), len(covs)), np.nan)
    for i, h in enumerate(HEMIS):
        for j, p in enumerate(targets):
            g = pk[(pk.hemisphere == h) & (pk.p == p)].set_index("winter_year").reindex(S.WINTERS)
            t_obs[i, j] = g.t.values
            o3_obs[i, j] = g.ozone_anomaly_ppmv.values
            cov[i, j] = g[covs].values

    # Check that SWOOSH sampling reproduces the paper's ozone series
    print("\nCheck: SWOOSH footprint ozone vs the paper's series (DJF means)")
    djf = np.nanmean(o3m[:, :, 3:6], axis=2)
    for i, h in enumerate(HEMIS):
        for j, p in enumerate(targets):
            k = int(np.argmin(np.abs(swl - (68.13 if p == 68.1 else 100.0))))
            ok = np.isfinite(djf[i, :, k]) & np.isfinite(o3_obs[i, j])
            diff = np.max(np.abs(djf[i, ok, k] - o3_obs[i, j, ok])) if ok.any() else np.nan
            r = np.corrcoef(djf[i, ok, k], o3_obs[i, j, ok])[0, 1] if ok.sum() > 2 else np.nan
            flag = "OK" if diff < 2e-3 else "CHECK: sampling differs from the paper"
            print(f"  {h:5s} {p:5.1f} hPa  max |diff| = {diff:.2e} ppmv, r = {r:.4f}   {flag}")

    ds_out = xr.Dataset(
        {
            "T_bg": (("hemisphere", "plev"), np.stack([prof[h]["t"] for h in HEMIS])),
            "q_bg": (("hemisphere", "plev"), np.stack([prof[h]["q"] for h in HEMIS])),
            "o3_vmr_bg": (("hemisphere", "plev"), np.stack([prof[h]["o3"] for h in HEMIS]) * M_AIR / M_O3),
            "cc_bg": (("hemisphere", "plev"), np.stack([prof[h]["cc"] for h in HEMIS])),
            "clwc_bg": (("hemisphere", "plev"), np.stack([prof[h]["clwc"] for h in HEMIS])),
            "ciwc_bg": (("hemisphere", "plev"), np.stack([prof[h]["ciwc"] for h in HEMIS])),
            "skt_bg": (("hemisphere",), np.array([prof[h]["skt"] for h in HEMIS])),
            "sp_bg": (("hemisphere",), np.array([prof[h]["sp"] for h in HEMIS])),
            "fal_bg": (("hemisphere",), np.array([prof[h]["fal"] for h in HEMIS])),
            "lat_centroid": (("hemisphere",), np.array([float((wts[h] * lat[:, None]).sum()) for h in HEMIS])),
            "o3_anom_ppmv": (("hemisphere", "winter", "month", "swoosh_level"), o3m),
            "t_obs": (("hemisphere", "target", "winter"), t_obs),
            "o3_obs": (("hemisphere", "target", "winter"), o3_obs),
            "covariates": (("hemisphere", "target", "winter", "cov"), cov),
        },
        coords=dict(hemisphere=HEMIS, plev=plev, swoosh_level=swl, winter=S.WINTERS, month=MONTH6,
                    target=targets, cov=covs),
        attrs=dict(mask=S.MASK, note="Background = footprint-weighted ERA5 DJF mean 2005-2025; "
                   "ozone anomalies = SWOOSH combinedo3q, 1991-2020 calendar-month reference."),
    )
    out = Path(S.RESULTS_DIR) / "radiation_inputs.nc"
    ds_out.to_netcdf(out)
    log(f"Wrote {out}. Next: run 06b_run_radiation.py on Linux, Mac, WSL or Google Colab (see README).")


if __name__ == "__main__":
    main()
