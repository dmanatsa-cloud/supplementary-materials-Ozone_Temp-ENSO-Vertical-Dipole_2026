# Ozone heating or shared transport? Three decisive tests

This toolkit runs the three tests that the paper leaves open:

1. **N2O tracer test.** Aura MLS nitrous oxide is a long-lived tracer that does not heat the air. If rising air explains the ozone-temperature link, N2O should carry the same information and absorb the ozone association when added to the model.
2. **Residual upwelling test.** ERA5 transformed Eulerian mean upwelling (w*) measures large-scale tropical upwelling directly. Adding it tests whether residual upwelling beyond the ENSO terms already in the model accounts for the link.
3. **Radiation calculation.** RRTMG (through climlab) computes how much the observed ozone anomalies actually heat each footprint, and how much temperature change that heating produces. This turns the paper's magnitude screen into a quantitative test.

Every script reads its paths from `settings.py`, skips work already done, and can be stopped and restarted at any time.

## Time and disk budget

| Step | What | Download | Time (typical) |
|---|---|---|---|
| 1 | MLS N2O, 1,890 daily files of about 1.6 MB | about 3 GB, deleted as it goes | 2 to 6 hours |
| 3 | ERA5 6-hourly v, T, omega, 63 monthly requests | about 5 GB, deleted as it goes | 1 to 2 days (CDS queue) |
| 5 | ERA5 monthly columns, 7 requests | about 0.5 GB, kept | 1 to 3 hours |
| 6b | Radiation calculation in Google Colab | none | about 10 minutes |
| others | Building series and running tests | none | minutes |

Steps 1, 3 and 5 can run at the same time in separate windows. Keep at least 20 GB free on the drive that holds `DATA_DIR`.

## Step 1. Install Python (once)

1. Download **Miniforge3-Windows-x86_64.exe** from https://github.com/conda-forge/miniforge/releases/latest and install it "Just Me" with the default options.
2. Open **Miniforge Prompt** from the Start menu. Use this window for every command below.
3. Go to the toolkit folder and create the environment:

```
cd "C:\path\to\ENSO_ozone_mechanism_tests"
mamba env create -f environment.yml
conda activate enso-mech
```

Run `conda activate enso-mech` again each time you open a new Miniforge Prompt.

## Step 2. Create the two accounts (once)

**NASA Earthdata (for MLS).**

1. Register at https://urs.earthdata.nasa.gov.
2. In your Earthdata profile, open **Applications**, then **Authorized Apps**, then **Approve More Applications**. Approve **NASA GESDISC DATA ARCHIVE**. Downloads fail with an authorization error until you do this.
3. Step 1 asks for your username and password the first time and saves them. You do not need to create any file.

**Copernicus Climate Data Store (for ERA5).**

1. Register at https://cds.climate.copernicus.eu and log in.
2. Accept the data licence. Open each of these dataset pages, go to the **Download** tab, and accept the terms at the bottom:
   - ERA5 hourly data on pressure levels from 1940 to present
   - ERA5 monthly averaged data on pressure levels from 1940 to present
   - ERA5 monthly averaged data on single levels from 1940 to present
3. Copy your **API token** from your CDS profile page.
4. Open Notepad and type two lines, with your own token:

```
url: https://cds.climate.copernicus.eu/api
key: your-token-here
```

5. Save it in your home folder (for example `C:\Users\ict`) as `.cdsapirc`. In the Save dialog choose **Save as type: All files**, so Notepad does not add `.txt`.

## Step 3. Edit settings.py (once)

Open `settings.py` in Notepad and set three paths:

- `PACKAGE_OUTPUTS`: the `outputs` folder of the reproducibility package.
- `SWOOSH_FILE`: your `swoosh-v02.73-198401-202606-lonlatpress-20deg-5deg-L31.nc`.
- `DATA_DIR`: a working folder **outside OneDrive**, for example `C:\ENSO_mechanism_data`.

## Step 4. Check the set-up

```
python 00_check_setup.py --online
python 99_selftest.py
```

The check must end with "All required checks passed". The self-test builds small synthetic files in the real formats, runs every step on them and ends with a PASS list. On Windows, "06b radiation" shows as skipped. That is expected; step 8 runs it in Colab.

## Step 5. Download (can run in parallel)

Open three Miniforge Prompt windows, activate the environment in each, and run one command per window. Start with the pilot runs to see the speed, then run the full set.

```
python 01_download_mls.py --pilot
python 01_download_mls.py

python 03_download_era5_wstar.py --pilot
python 03_download_era5_wstar.py

python 05_download_era5_radiation.py
```

Notes:

- If a window closes or the internet drops, run the same command again. Finished days and months are skipped.
- CDS requests wait in a queue. Progress is visible at https://cds.climate.copernicus.eu/requests.
- `--dry-run` on steps 1, 3 and 5 shows what would be requested without downloading.
- The MLS N2O receiver has run only part of each month since May 2024, so winter 2025 has fewer profiles. Step 2 reports this.

## Step 6. Build the tracer, upwelling and radiation inputs

```
python 02_build_n2o_footprints.py
python 04_build_wstar_index.py
python 06a_prepare_radiation_inputs.py
```

Check what they print:

- Step 2 lists the correlation of footprint N2O with the paper's SWOOSH ozone. A clear negative value (about -0.5 or stronger) is normal, because rising air raises N2O and lowers ozone.
- Step 4 prints the mean tropical w*. It should be about 0.2 to 0.5 mm/s, and its correlation with Nino 3.4 should be positive.
- Step 6a prints four "OK" lines. They confirm that the SWOOSH sampling in this toolkit reproduces the paper's ozone series. If any line says CHECK, stop and send me the printout.

## Step 7. Transport tests

```
python 07_transport_tests.py
python 07_transport_tests.py --exclude-winters 2025
```

Results are in `RESULTS_DIR`: `transport_tests.md` (plain-language reading), `transport_tests.csv`, `transport_diagnostics.csv` and `transport_tests.png`. The second command checks that the thin 2025 N2O winter does not drive the result.

## Step 8. Radiation calculation in Google Colab

climlab's RRTMG code has no Windows build, so this one step runs in Colab, which is free and needs only a Google account.

1. Go to https://colab.research.google.com, choose **File, Upload notebook**, and select `radiation_colab.ipynb`.
2. Choose **Runtime, Run all**.
3. When asked, upload `06b_run_radiation.py` (toolkit folder) and `radiation_inputs.nc` (your `RESULTS_DIR`).
4. The notebook shows the summary and downloads `radiation_results.zip`. Unzip it into `RESULTS_DIR`.

Alternative without Colab: install WSL (`wsl --install -d Ubuntu` in an administrator PowerShell), install Miniforge for Linux inside Ubuntu, then run `mamba env create -f environment_radiation.yml`, `conda activate enso-rad` and `python 06b_run_radiation.py /mnt/c/ENSO_mechanism_data/results/radiation_inputs.nc --out /mnt/c/ENSO_mechanism_data/results/radiation`.

## Step 9. How to read the results

`radiation_summary.md` gives, for each footprint and level:

- the ozone heating sensitivity for the observed shape of the ozone anomaly (K/day per ppmv), computed for these columns rather than read from a figure;
- the effective radiative balance time, to compare with the 30 and 41 days the paper's slopes require;
- the **radiative response ratio**: the step response (covariate-adjusted DJF profile imposed as a constant perturbation from 1 September, averaged over December-February) divided by the observed conditional slope, with a range from slope uncertainty alone;
- a per-winter experiment driven by each winter's monthly profiles. Run `python 08_post_subtraction.py` afterwards for its four-region inference (Table S11 of the GRL Supporting Information).

How to read them:

- The response ratio is conditional on the column, the ozone profile and fixed dynamical heating. It is not a causal fraction, a fraction of variance or a fraction of the composite lobe anomaly. Report the model-choice range (sky, boundary, truncation) next to it.
- The transport tests use the original temperature series, not temperature minus the radiative prediction, so the radiation and transport results do not add up to a partition.
- A control that leaves the association unchanged shows only that the control does not track the relevant variability. Check its partial correlation with ozone and temperature (tracer strength) before reading it as evidence against transport.
- Apply the same four-region inference to the post-subtraction test as to the principal model. A result that does not pass q_cons < 0.05 is suggestive at most.

The w* test answers a narrower question: whether the zonal-mean residual upwelling index accounts for the link beyond the ENSO terms already in the model. It cannot test local transport.

Send me `transport_tests.md`, `transport_tests.csv`, `radiation_summary.md`, `radiation_summary.csv` and the printouts from steps 2, 4 and 6a. I will fold the results into the manuscript.

## Troubleshooting

| Message | Fix |
|---|---|
| Earthdata 401 or "authorization" error | Approve NASA GESDISC DATA ARCHIVE in your Earthdata profile (Step 2) |
| "required licences not accepted" from CDS | Accept the licence on each ERA5 dataset page (Step 2) |
| CDS "invalid key" or 401 | Check `.cdsapirc`: two lines, url and key, no `.txt` extension |
| "No ML2N2O files found" | Check `MLS_VERSION = "006"` in settings.py; `"005"` also works |
| Step 6a says CHECK | Do not continue; send the printout |
| Disk full | Raw files are deleted automatically; delete `DATA_DIR\selftest` if present |

## Methods notes for the paper

- MLS: Level 2 v6 N2O, screened with the v6.0x data quality document (even Status, Quality above 0.8, Convergence below 2.0, positive precision), binned to the native SWOOSH cells and weighted with the paper's footprint weights.
- w*: transformed Eulerian mean residual vertical velocity in pressure coordinates (Andrews, Holton and Leovy, 1987), from 6-hourly ERA5 on a 1.5 degree grid, averaged 20S-20N.
- Radiation: RRTMG (Iacono et al., 2008) through climlab (Rose, 2018), single-column footprint-mean DJF profiles, fixed dynamical heating above 125 hPa, with 100 and 150 hPa as sensitivities.

References: Iacono, M. J., et al. (2008), J. Geophys. Res., 113, D13103, doi:10.1029/2008JD009944. Rose, B. E. J. (2018), J. Open Source Softw., 3(24), 659, doi:10.21105/joss.00659. Andrews, D. G., Holton, J. R., and Leovy, C. B. (1987), Middle Atmosphere Dynamics, Academic Press.

## Files

| File | Purpose |
|---|---|
| `settings.py` | Paths and choices (edit once) |
| `00_check_setup.py` | Checks packages, paths, logins and disk |
| `01_download_mls.py` | MLS download and reduction |
| `02_build_n2o_footprints.py` | N2O footprint winter series |
| `03_download_era5_wstar.py` | ERA5 download and TEM reduction |
| `04_build_wstar_index.py` | w* winter indices |
| `05_download_era5_radiation.py` | ERA5 monthly columns |
| `06a_prepare_radiation_inputs.py` | Builds `radiation_inputs.nc` (Windows) |
| `06b_run_radiation.py` | RRTMG calculation (Colab, Linux, macOS or WSL) |
| `07_transport_tests.py` | Regression tests with N2O and w* |
| `08_post_subtraction.py` | Four-region inference for the per-winter radiative experiment (Table S11 of the GRL Supporting Information) |
| `99_selftest.py` | End-to-end test on synthetic files |
| `radiation_colab.ipynb` | Colab notebook for step 6b |
| `common.py`, `mls_reader.py`, `tem.py`, `selftest/` | Shared code |
