"""Step 5. Download ERA5 monthly-mean columns for the radiation calculation.

Seven requests: six pressure-level variables on all 37 levels and one
single-level request. Region 200-230 E, 29.5 S-29.5 N on the same 0.5
degree grid as the footprints; December, January and February 2004-2025.
Total about 0.5 GB. Files are kept (the next step needs them).

  python 05_download_era5_radiation.py
  python 05_download_era5_radiation.py --dry-run
"""
import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import settings as S  # noqa: E402
from common import ensure_dirs, log  # noqa: E402

LEVELS = [1, 2, 3, 5, 7, 10, 20, 30, 50, 70, 100, 125, 150, 175, 200, 225, 250, 300, 350, 400,
          450, 500, 550, 600, 650, 700, 750, 775, 800, 825, 850, 875, 900, 925, 950, 975, 1000]
PL_VARS = ["temperature", "specific_humidity", "ozone_mass_mixing_ratio", "fraction_of_cloud_cover",
           "specific_cloud_liquid_water_content", "specific_cloud_ice_water_content"]
SL_VARS = ["skin_temperature", "surface_pressure", "forecast_albedo"]


def base_request():
    return {
        "product_type": ["monthly_averaged_reanalysis"],
        "year": [str(y) for y in S.RAD_YEARS],
        "month": ["01", "02", "12"],
        "time": ["00:00"],
        "data_format": "netcdf",
        "download_format": "unarchived",
        "area": S.RAD_AREA,
        "grid": [S.RAD_GRID_DEG, S.RAD_GRID_DEG],
    }


def jobs():
    out = Path(S.DATA_DIR) / "era5_radiation"
    out.mkdir(parents=True, exist_ok=True)
    for v in PL_VARS:
        r = base_request()
        r.update(variable=[v], pressure_level=[str(p) for p in LEVELS])
        yield "reanalysis-era5-pressure-levels-monthly-means", r, out / f"pl_{v}.nc"
    r = base_request()
    r.update(variable=SL_VARS)
    yield "reanalysis-era5-single-levels-monthly-means", r, out / "sl_surface.nc"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    ensure_dirs()
    if a.dry_run:
        for ds, r, target in jobs():
            print(ds, "->", target.name)
            print(json.dumps(r)[:400], "...\n")
        return
    import cdsapi
    client = cdsapi.Client()
    for ds, r, target in jobs():
        if target.exists():
            log(f"{target.name} already present")
            continue
        for attempt in range(1, 4):
            try:
                log(f"requesting {target.name}")
                client.retrieve(ds, r, str(target))
                break
            except Exception as e:
                log(f"  attempt {attempt} failed: {e}")
                target.unlink(missing_ok=True)
                time.sleep(30 * attempt)
    log("Done. Next: python 06a_prepare_radiation_inputs.py")


if __name__ == "__main__":
    main()
