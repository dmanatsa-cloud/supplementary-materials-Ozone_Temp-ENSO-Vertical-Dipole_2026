"""Step 4. Build DJF residual-upwelling (w*) indices from the reduced monthly TEM files.

Writes RESULTS_DIR/wstar_winter.csv with, for each winter and each
temperature region, the w* anomaly (mm/s) at the matching level:
  wstar_tropics : cos-weighted 20S-20N mean (the usual tropical upwelling index)
  wstar_band    : the region's own hemisphere, 0-25 degrees
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import settings as S  # noqa: E402
from common import REGIONS, djf_months, ensure_dirs, load_package_winter, log  # noqa: E402
from tem import band_mean  # noqa: E402


def main():
    ensure_dirs()
    red = Path(S.DATA_DIR) / "era5_wstar" / "reduced"
    rows = []
    missing = []
    for w in S.WINTERS:
        vals = []
        for y, m in djf_months(w):
            f = red / f"{y}{m:02d}.npz"
            if not f.exists():
                missing.append(f"{y}-{m:02d}")
                vals = None
                break
            vals.append(np.load(f))
        if vals is None:
            continue
        lat = vals[0]["latitude"]
        lev = vals[0]["level_hpa"]
        ws = np.mean([v["wstar_mm_s"] for v in vals], axis=0)
        wb = np.mean([v["wbar_mm_s"] for v in vals], axis=0)
        for hemi, p in REGIONS:
            k = int(np.argmin(np.abs(lev - (70 if p == 68.1 else 100))))
            lo, hi = (-25, 0) if hemi == "south" else (0, 25)
            rows.append(dict(winter_year=w, hemisphere=hemi, p=p, level_hpa=lev[k],
                             wstar_tropics=band_mean(ws[k], lat, *S.WSTAR_TROPICS),
                             wstar_band=band_mean(ws[k], lat, lo, hi),
                             wbar_tropics=band_mean(wb[k], lat, *S.WSTAR_TROPICS)))
    if missing:
        log(f"Months not yet downloaded ({len(missing)}): {', '.join(missing[:12])}{' ...' if len(missing) > 12 else ''}")
    if not rows:
        sys.exit("No complete winters yet. Run 03_download_era5_wstar.py first.")
    d = pd.DataFrame(rows)
    clim = d.groupby(["hemisphere", "p"])[["wstar_tropics", "wstar_band", "wbar_tropics"]].transform("mean")
    print("\nDJF climatology (mm/s); tropical upwelling is normally 0.2-0.5 mm/s at 70-100 hPa:")
    print(d.groupby("level_hpa")[["wstar_tropics", "wbar_tropics"]].mean().round(3).to_string())
    for c in ("wstar_tropics", "wstar_band", "wbar_tropics"):
        d[c + "_mean"] = d[c]
        d[c] = d[c] - clim[c]
    out = Path(S.RESULTS_DIR) / "wstar_winter.csv"
    d.to_csv(out, index=False)
    log(f"Wrote {out} ({d.winter_year.nunique()} winters)")

    pk = load_package_winter()[["winter_year", "nino34"]].drop_duplicates("winter_year")
    m = d[(d.hemisphere == "south") & (d.p == 68.1)].merge(pk, on="winter_year")
    if len(m) > 3:
        r = np.corrcoef(m.wstar_tropics, m.nino34)[0, 1]
        print(f"\nCheck: correlation of 70 hPa tropical w* with Nino 3.4 = {r:+.2f} "
              "(El Nino strengthens upwelling, so this should be positive).")


if __name__ == "__main__":
    main()
