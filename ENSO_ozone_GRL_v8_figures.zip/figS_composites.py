"""Figures S1 and S2 in the style of Figure 1.

  python figS_composites.py S1   # volcanic warm winters 1983 and 1992 omitted, no test
  python figS_composites.py S2   # detrended, hatched where q < 0.05
"""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, NullLocator

S = "/tmp/claude-0/-home-claude/af5d699d-9d1f-5e9e-81f6-15ed2f2f7a92/scratchpad"
z = np.load(f"{S}/pkg/outputs/ENSO_ozone_review_revision_2026_10_06/review_composite_sections.npz")
lat, p = z["latitude"], z["pressure_hpa"]

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.titlelocation": "left",
                     "hatch.color": "#2b2b2b", "hatch.linewidth": 0.45, "axes.linewidth": 0.7,
                     "xtick.major.width": 0.7, "ytick.major.width": 0.7})
W, H = 6.5, 7.0
fig = plt.figure(figsize=(W, H))
L0, PW, CB, GAP = 0.64, 2.17, 0.09, 0.62   # inches: left margin, panel width, colorbar width, gap after colorbar
BOT, PH, VG, TOPM = 0.45, 1.88, 0.34, 0.27
axs = np.empty((3, 2), dtype=object); cax = {}
for r in range(3):
    y = BOT + (2 - r) * (PH + VG)
    for c in range(2):
        x = L0 + c * (PW + 0.06 + CB + GAP)
        axs[r, c] = fig.add_axes([x / W, y / H, PW / W, PH / H])
for c in range(2):
    x = L0 + c * (PW + 0.06 + CB + GAP) + PW + 0.06
    ytop = BOT + 2 * (PH + VG) + PH; ymid = BOT + (PH + VG)
    cax[(c, "comp")] = fig.add_axes([x / W, (ymid + 0.1) / H, CB / W, (ytop - ymid - 0.2) / H])
    cax[(c, "diff")] = fig.add_axes([x / W, (BOT + 0.1) / H, CB / W, (PH - 0.2) / H])
LT = np.arange(-4, 4.01, 0.5); LW = np.arange(-0.04, 0.0401, 0.005)
WHICH = sys.argv[1]
PRE = {"S1": "no_1983_1992_raw", "S2": "objective_detrended"}[WHICH]
rows = [(f"{PRE}_el_nino", "El Niño", 1), (f"{PRE}_la_nina", "La Niña", 1),
        (f"{PRE}_difference", "El Niño minus La Niña", 2)]
cs_t, cs_w = {}, {}
for r, (key, name, scale) in enumerate(rows):
    for c, (var, cmap, lev) in enumerate([("t", "RdBu_r", LT), ("w", "BrBG_r", LW)]):
        ax = axs[r, c]
        if f"{key}_{var}" in z.files:
            f = z[f"{key}_{var}"]
        else:
            f = z[f"{PRE}_el_nino_{var}"] - z[f"{PRE}_la_nina_{var}"]
        cs = ax.contourf(lat, p, f, levels=lev * scale, cmap=cmap, extend="both")
        ax.contour(lat, p, f, levels=[0], colors="#444444", linewidths=0.6)
        if r == 2 and f"{key}_{var}_q" in z.files:
            q = z[f"{key}_{var}_q"]
            ax.contourf(lat, p, q, levels=[0, 0.05], colors="none", hatches=["////"])
        for pp in (70, 100, 200, 300):
            ax.axhline(pp, color="#555555", lw=0.5, ls=(0, (1, 2)))
        ax.set_title(f"{'abcdef'[2 * r + c]}  {name}", pad=3)
        (cs_t if var == "t" else cs_w)[r] = cs
for ax in axs.flat:
    ax.set_yscale("log"); ax.set_ylim(1000, 50)
    ax.yaxis.set_major_locator(FixedLocator([50, 70, 100, 150, 200, 300, 500, 700, 1000]))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.set_yticklabels(["50", "70", "100", "150", "200", "300", "500", "700", "1000"])
    ax.set_xticks([-25, -15, 0, 15, 25]); ax.set_xticklabels(["25°S", "15°S", "EQ", "15°N", "25°N"])
for ax in axs[:, 0]:
    ax.set_ylabel("Pressure (hPa)")
for c, (cs_set, label) in enumerate([(cs_t, "Temperature (K)"), (cs_w, "Omega (Pa s⁻¹)")]):
    for kind, cs, mult in [("comp", cs_set[0], 1), ("diff", cs_set[2], 2)]:
        cb = fig.colorbar(cs, cax=cax[(c, kind)])
        cb.ax.tick_params(labelsize=8, width=0.6, length=2.5)
        cb.set_label(label, fontsize=8)
        cb.set_ticks((np.arange(-4, 5, 2) if c == 0 else np.array([-0.04, -0.02, 0, 0.02, 0.04])) * mult)
for ax in axs[:2].flat:
    ax.tick_params(labelbottom=False)
for ax in axs[:, 1]:
    ax.tick_params(labelleft=False)
for ax in axs[2]:
    ax.set_xlabel("Latitude")
for ext in ("png", "pdf"):
    fig.savefig(f"{S}/v8figs/Fig{WHICH}_composites.{ext}", dpi=300)
print("ok")
