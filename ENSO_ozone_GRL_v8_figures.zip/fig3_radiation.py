"""Figure 3 for GRL: radiative response to the observed ozone anomaly profiles (6.5 in wide, fonts >= 8 pt)."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import NullFormatter, ScalarFormatter

S = "/tmp/claude-0/-home-claude/af5d699d-9d1f-5e9e-81f6-15ed2f2f7a92/scratchpad"
D = f"{S}/radreal"
SOUTH, NORTH, ORANGE, GRAY, INK = "#1f4e79", "#b5402f", "#e07b2a", "#8a8984", "#1f1f1f"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.titlelocation": "left",
                     "axes.linewidth": 0.7})
pr = pd.read_csv(f"{D}/profiles_principal.csv")
sm = pd.read_csv(f"{D}/summary.csv")
REG = {"S68": ("south", 68.1, 68.1292, "South 68.1 hPa", SOUTH), "N100": ("north", 100.0, 100.0, "North 100.0 hPa", NORTH)}


def logp(ax):
    ax.set_yscale("log"); ax.set_ylim(200, 20)
    ax.set_yticks([200, 150, 100, 70, 50, 30, 20])
    ax.yaxis.set_major_formatter(ScalarFormatter()); ax.yaxis.set_minor_formatter(NullFormatter())
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="x", color="#e6e5e0", lw=0.5); ax.axvline(0, color="#bdbcb6", lw=0.7)
    ax.tick_params(labelsize=8)


def row(reg, sky="all", top=125):
    h, t = REG[reg][0], REG[reg][1]
    return sm[(sm.hemisphere == h) & (sm.target == t) & (sm.sky == sky) & (sm.fdh_top == top)].iloc[0]


fig, axs = plt.subplots(2, 3, figsize=(6.5, 5.5), sharey=True)
letters = iter("abcdef")
for i, reg in enumerate(["S68", "N100"]):
    g = pr[pr.region == reg]; tp = REG[reg][2]; r = row(reg); col = REG[reg][4]
    ax = axs[i, 0]
    ax.plot(g["shape"], g.p, color=col, lw=1.4)
    ax.plot([1], [tp], "o", ms=5, color=col, mec="white", mew=1.0)
    ax.set_title(f"{next(letters)}  {REG[reg][3]}: ozone")
    ax.set_xlabel("ppmv per ppmv at target"); logp(ax)
    ax.set_xlim(-1.5, 5.0 if reg == "N100" else 2.0)
    ax = axs[i, 1]
    ax.plot(g.dQ, g.p, color=ORANGE, lw=1.4)
    ax.plot([r.beta_shape], [tp], "o", ms=5, color=ORANGE, mec="white", mew=1.0)
    ax.annotate(f"{r.beta_shape:.2f}", (r.beta_shape, tp), xytext=(6, -10), textcoords="offset points", fontsize=8)
    ax.set_title(f"{next(letters)}  Heating change")
    ax.set_xlabel("K day$^{-1}$ per ppmv"); logp(ax); ax.set_xlim(-0.4, 0.9)
    ax = axs[i, 2]
    ax.plot(g.dTeq, g.p, color=GRAY, lw=1.3)
    ax.errorbar([r.M_obs], [tp], xerr=[[r.M_obs - r.M_lo], [r.M_hi - r.M_obs]], fmt="o", ms=5, color=col,
                mec="white", mew=1.0, elinewidth=1.6, capsize=0, zorder=5)
    ax.plot([r.M_tr], [tp], "s", ms=5.5, color=ORANGE, mec="white", mew=1.0, zorder=6)
    ax.annotate(f"ratio {r.frac_tr:.2f}", (r.M_tr, tp), xytext=(0, 9), textcoords="offset points", fontsize=8, ha="center")
    ax.set_title(f"{next(letters)}  Temperature change")
    ax.set_xlabel("K per ppmv"); logp(ax); ax.set_xlim(-8, 70)
for ax in axs[:, 0]:
    ax.set_ylabel("Pressure (hPa)")
handles = [Line2D([], [], color=GRAY, lw=1.3, label="Equilibrium"),
           Line2D([], [], marker="s", ls="", color=ORANGE, ms=5.5, label="Step response from 1 September"),
           Line2D([], [], marker="o", ls="-", color=INK, ms=5, lw=1.4, label="Observed slope, 95% interval")]
fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False, fontsize=8, handletextpad=0.4, columnspacing=1.2)
fig.tight_layout(rect=(0, 0.05, 1, 1), h_pad=1.0, w_pad=0.8)
for ext in ("png", "pdf"):
    fig.savefig(f"{S}/v8figs/Fig3_radiation.{ext}", dpi=300)
print("ok")
