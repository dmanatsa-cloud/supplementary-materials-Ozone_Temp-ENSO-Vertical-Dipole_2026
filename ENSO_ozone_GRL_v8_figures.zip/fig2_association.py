"""Figure 2 for GRL: adjusted scatter in the two principal regions, and robustness and mismatched-ozone checks."""
import os
import sys

S = "/tmp/claude-0/-home-claude/af5d699d-9d1f-5e9e-81f6-15ed2f2f7a92/scratchpad"
R = f"{S}/recalc_prev/recalculation_2026_10_07"
os.environ["ENSO_PKG_OUTPUTS"] = f"{S}/pkg/outputs"
sys.path.insert(0, R)
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import matplotlib  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from core import MODELS, PKG, design, resid  # noqa: E402

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.titlelocation": "left",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.7})
SOUTH, NORTH, GREY, INK = "#1f4e79", "#b5402f", "#8c8c8c", "#1f1f1f"
d = pd.read_csv(f"{PKG}/Focused_ozone_evidence_2026_10_06/observed_ozone_T_cloud_lobe_winter_2005_2025.csv")
d["p"] = d.pressure_hpa.round(1)
A = pd.read_csv(f"{R}/all_results.csv")
C = pd.read_csv(f"{R}/controls.csv")
full = A[A["sample"] == "full"]

fig = plt.figure(figsize=(6.5, 7.2))
axa = fig.add_axes([0.105, 0.665, 0.355, 0.30])
axb = fig.add_axes([0.615, 0.665, 0.355, 0.30])
axc = fig.add_axes([0.385, 0.065, 0.585, 0.425])

for ax, (h, p), col, lab in [(axa, ("south", 68.1), SOUTH, "a  South 68.1 hPa"), (axb, ("north", 100.0), NORTH, "b  North 100.0 hPa")]:
    g = d[(d.hemisphere == h) & (d.p == p)]
    g2, Cm = design(g, MODELS["expanded"])
    rx = resid(g2.ozone_anomaly_ppmv.to_numpy(float), Cm)
    ry = resid(g2.t.to_numpy(float), Cm)
    row = full[(full.region == f"{h} {p}") & (full.model == "expanded")].iloc[0]
    b = rx @ ry / (rx @ rx)
    assert abs(b - row.slope) < 1e-6 * max(1, abs(b)), (b, row.slope)
    xs = np.linspace(rx.min(), rx.max(), 2)
    ax.axhline(0, color="#c8c8c8", lw=0.7, zorder=0); ax.axvline(0, color="#c8c8c8", lw=0.7, zorder=0)
    ax.plot(xs, b * xs, color=col, lw=1.4)
    ax.scatter(rx, ry, s=22, color=col, edgecolor="white", linewidth=0.6, zorder=3)
    ax.set_title(lab)
    ax.text(0.97, 0.04, f"partial r = {row.partial_r:.2f}\n$q_{{\\mathrm{{cons}}}}$ = {row.q_cons:.4f}\n"
            f"slope = {row.slope:.1f} K ppmv$^{{-1}}$", transform=ax.transAxes, ha="right", va="bottom", fontsize=8)
    ax.set_xlabel("Adjusted ozone anomaly (ppmv)"); ax.set_ylabel("Adjusted temperature (K)")
    ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(5))
    ax.tick_params(labelsize=8)

specs = [("full", "Principal model, 21 winters"), ("mask_threshold_1p5K", "1.5 K mask threshold"),
         ("mask_threshold_2p5K", "2.5 K mask threshold"), ("mask_geometric_0_20deg", "Fixed 0–20° box"),
         ("mask_pre2005_only_2K", "Pre-2005 mask training"), ("mask_pre2005_independent_reference_2K", "Independent pre-2005 mask"),
         ("RONI_covariate", "RONI replaces Niño 3.4"), ("omit_bias_2005_2007", "Omit 2005–2007"),
         ("omit_2016", "Omit 2016"), ("omit_2023_2025", "Omit 2023–2025"), ("omit_2016_2023_2025", "Omit 2016 and 2023–2025")]
mism = [("other level", "Mismatched: other level"), ("other hemisphere", "Mismatched: other hemisphere"),
        ("other level and hemisphere", "Mismatched: other level and hemisphere")]
nrow = len(specs) + len(mism) + 1
OFF = {("south 68.1", "expanded"): 0.27, ("south 68.1", "with_transport"): 0.09,
       ("north 100.0", "expanded"): -0.09, ("north 100.0", "with_transport"): -0.27}
COL = {"south 68.1": SOUTH, "north 100.0": NORTH}
npass = ntot = 0
labels, ypos = [], []
for i, (sk, sl) in enumerate(specs):
    y = nrow - 1 - i
    labels.append(sl); ypos.append(y)
    for reg in ("south 68.1", "north 100.0"):
        for mdl in ("expanded", "with_transport"):
            r = A[(A["sample"] == sk) & (A.region == reg) & (A.model == mdl)].iloc[0]
            ok = r.q_cons < 0.05; npass += ok; ntot += 1
            yy = y + OFF[(reg, mdl)]
            if sk == "full":
                axc.plot([r.loo_min, r.loo_max], [yy, yy], color=COL[reg], lw=1.0, alpha=0.55, zorder=2)
            axc.scatter(r.partial_r, yy, marker="o" if mdl == "expanded" else "s", s=20,
                        color=COL[reg] if ok else "white", edgecolor=COL[reg], linewidth=1.0, zorder=3)
for j, (kind, sl) in enumerate(mism):
    y = nrow - 1 - len(specs) - 1 - j
    labels.append(sl); ypos.append(y)
    for reg in ("south 68.1", "north 100.0"):
        for mdl in ("expanded", "with_transport"):
            r = C[(C.T_region == reg) & (C.kind == kind) & (C.model == mdl)].iloc[0]
            axc.scatter(r.partial_r, y + OFF[(reg, mdl)], marker="o" if mdl == "expanded" else "s", s=20,
                        color="white", edgecolor=COL[reg], linewidth=1.0, zorder=3)
assert (npass, ntot) == (42, 44), (npass, ntot)
axc.axhline(nrow - 1 - len(specs) + 0.0, color="#bdbdbd", lw=0.7)
axc.axvline(0, color="#c8c8c8", lw=0.7, zorder=0)
axc.set_yticks(ypos); axc.set_yticklabels(labels, fontsize=8)
axc.set_ylim(-0.6, nrow - 0.4); axc.set_xlim(-0.45, 1.0)
axc.set_xlabel("Ozone–temperature partial correlation")
axc.tick_params(axis="y", length=0); axc.tick_params(axis="x", labelsize=8)
axc.spines["left"].set_visible(False)
fig.text(0.02, 0.585, "c  Robustness and mismatched ozone", fontsize=9, ha="left")
handles = [Line2D([], [], marker="o", ls="", color=SOUTH, ms=5, label="South 68.1 hPa"),
           Line2D([], [], marker="o", ls="", color=NORTH, ms=5, label="North 100.0 hPa"),
           Line2D([], [], marker="o", ls="", color=INK, ms=5, label="Principal covariates"),
           Line2D([], [], marker="s", ls="", color=INK, ms=5, label="Plus transport covariates"),
           Line2D([], [], marker="o", ls="", color=INK, mfc="white", ms=5, label="Not significant"),
           Line2D([], [], color=INK, alpha=0.55, lw=1.0, label="Leave-one-winter-out range")]
fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.02, 0.572), ncol=3, frameon=False, fontsize=8,
           handletextpad=0.4, columnspacing=1.4, borderaxespad=0)
for ext in ("png", "pdf"):
    fig.savefig(f"{S}/v8figs/Fig2_association.{ext}", dpi=300)
print("pass", npass, "of", ntot)
